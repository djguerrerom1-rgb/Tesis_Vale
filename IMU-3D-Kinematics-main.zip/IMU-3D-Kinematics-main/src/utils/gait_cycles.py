import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation as R
from scipy.signal import find_peaks

# def detectar_ciclos(fe_signal, min_dist=30, prominencia=15):
#     """
#     Detecta picos de flexión de rodilla para segmentar ciclos de marcha.
#     """
#     peaks, _ = find_peaks(fe_signal, distance=min_dist, prominence=prominencia)
#     ciclos = []
#     for i in range(len(peaks) - 1):
#         start = peaks[i]
#         end = peaks[i + 1]
#         if end - start > 30:  # evita ciclos muy cortos
#             ciclos.append((start, end))
#     return ciclos

def detectar_ciclos(signal, min_dist=40, altura_maxima=30):
    """
    Detecta valles en la señal de ángulos de rodilla (flexión-extensión).
    Parámetros:
        signal: np.array de la señal
        min_dist: separación mínima entre valles (en muestras)
        altura_maxima: umbral máximo para que un valle sea considerado (en grados)
    """
    inverted_signal = -np.array(signal)  # Buscar valles como picos en la señal invertida
    peaks, properties = find_peaks(inverted_signal, distance=min_dist)

    # Filtrar solo valles profundos (rodilla en extensión, bajo ángulo)
    valles = [p for p in peaks if signal[p] < altura_maxima]
    return valles

def normalizar_y_promediar(valles, señal, n_points=100):
    """
    Interpola cada ciclo entre valles consecutivos a n_points y devuelve media y std.
    
    Parámetros:
        valles: lista de índices donde empieza cada ciclo
        señal: señal original
        n_points: cantidad de puntos para interpolar cada ciclo
    """
    ciclos_interp = []

    # Recorre pares consecutivos de valles
    for i in range(len(valles) - 1):
        start = valles[i]
        end = valles[i + 1]
        segmento = señal[start:end]

        if len(segmento) > 1:  # Evitar divisiones por cero o segmentos vacíos
            interp = np.interp(
                np.linspace(0, 1, n_points),
                np.linspace(0, 1, len(segmento)),
                segmento
            )
            ciclos_interp.append(interp)

    if len(ciclos_interp) == 0:
        raise ValueError("No se detectaron ciclos válidos para interpolar.")

    matriz = np.vstack(ciclos_interp)
    media = np.mean(matriz, axis=0)
    std = np.std(matriz, axis=0)
    return media, std


# def normalizar_y_promediar(ciclos, señal, n_points=100):
#     """
#     Interpola cada ciclo a n_points y devuelve media y std.
#     """
#     ciclos_interp = []
#     for start, end in ciclos:
#         segmento = señal[start:end]
#         interp = np.interp(np.linspace(0, 1, n_points), np.linspace(0, 1, len(segmento)), segmento)
#         ciclos_interp.append(interp)
#     matriz = np.vstack(ciclos_interp)
#     media = np.mean(matriz, axis=0)
#     std = np.std(matriz, axis=0)
#     return media, std

def graficar_ciclos(mean_data, std_data, titulo, color):
    x = np.linspace(0, 100, len(mean_data))  # Ciclo de marcha de 0% a 100%
    
    plt.figure(figsize=(8, 4))
    plt.plot(x, mean_data, label='Promedio', color=color)
    plt.fill_between(x, mean_data - std_data, mean_data + std_data, color=color, alpha=0.3, label='Desviación estándar')
    
    plt.title(titulo)
    plt.xlabel('% Ciclo de marcha')
    plt.ylabel('Ángulo (°)')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()
