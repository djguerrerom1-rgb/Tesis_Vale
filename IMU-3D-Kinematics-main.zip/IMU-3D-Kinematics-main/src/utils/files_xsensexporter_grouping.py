import os
import shutil

def group_csv_files_by_suffix(main_folder_path):
    """
    Agrupa archivos CSV en carpetas según los últimos 6 dígitos de sus nombres
    y renombra las carpetas en orden numérico ascendente.
    
    Parámetros:
    - main_folder_path: Ruta a la carpeta principal donde se encuentran los archivos CSV.
    """
    folder_map = {}
    
    # Recorre todos los archivos en la carpeta principal
    for file_name in os.listdir(main_folder_path):
        if file_name.endswith(".csv"):
            # Obtiene los últimos 6 dígitos del nombre del archivo
            suffix = file_name[-10:-4]
            target_folder = os.path.join(main_folder_path, suffix)

            # Crea la carpeta si no existe
            if suffix not in folder_map:
                folder_map[suffix] = target_folder
                os.makedirs(target_folder, exist_ok=True)
            
            # Mueve el archivo a la carpeta correspondiente
            source_file_path = os.path.join(main_folder_path, file_name)
            target_file_path = os.path.join(target_folder, file_name)
            shutil.move(source_file_path, target_file_path)
            print(f"Moviendo {file_name} a {target_folder}")
    
    # Ordenar las carpetas por su número y renombrarlas secuencialmente
    sorted_folders = sorted(folder_map.keys(), key=lambda x: int(x))
    for index, old_name in enumerate(sorted_folders, start=1):
        old_path = os.path.join(main_folder_path, old_name)
        new_path = os.path.join(main_folder_path, str(index))
        if os.path.exists(new_path):
            shutil.rmtree(new_path)  # Elimina la carpeta si ya existe
        os.rename(old_path, new_path)
        print(f"Renombrando {old_name} -> {index}")

# Ingresar la ruta de la carpeta principal
main_folder = input("Ingresa la ruta de la carpeta principal: ")
group_csv_files_by_suffix(main_folder)