import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from scipy.spatial.distance import directed_hausdorff
import matplotlib.cm as cm
import seaborn as sns

try:
    from similaritymeasures import frechet_dist
    HAS_FRECHET = True
except ImportError:
    HAS_FRECHET = False
    print("⚠️ similaritymeasures no está instalado. Se usará Hausdorff como alternativa para Fréchet.")

# # === RUTAS ===
# base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
# file_xsens_todos = os.path.join(base_path, 'CICLOS_XSENS_TODOS.xlsx')
# file_3dma_todos = os.path.join(base_path, 'CICLOS_3DMA_TODOS.xlsx')
# file_xsens_copia = os.path.join(base_path, 'CICLOS_XSENS_COPIA.xlsx')
# file_3dma_copia = os.path.join(base_path, 'CICLOS_3DMA_COPIA.xlsx')

# ANGULOS = [
#     'cadera_der_f_e', 'cadera_der_abd_add',
#     'cadera_izq_f_e', 'cadera_izq_abd_add',
#     'rodilla_der_f_e', 'rodilla_der_abd_add',
#     'rodilla_izq_f_e', 'rodilla_izq_abd_add',
#     'tobillo_der_f_e', 'tobillo_izq_f_e'
# ]
# NORM_POINTS = 100

# # # 1. GRAFICAR TODOS LOS CICLOS
# # def graficar_todos_por_hoja(file_path, metodo):
# #     imgs_folder = os.path.join(base_path, f'IMGS_CICLOS_TODOS_{metodo.upper()}')
# #     os.makedirs(imgs_folder, exist_ok=True)
# #     with pd.ExcelFile(file_path) as xls:
# #         for hoja in xls.sheet_names:
# #             df = pd.read_excel(xls, sheet_name=hoja)
# #             ciclos = df.drop(columns=['Ciclo de marcha (%)'], errors='ignore')
# #             t = df['Ciclo de marcha (%)'] if 'Ciclo de marcha (%)' in df else np.linspace(0, 100, NORM_POINTS)
# #             plt.figure(figsize=(10, 5))
# #             for col in ciclos.columns:
# #                 plt.plot(t, ciclos[col], alpha=0.4, label=col)
# #             plt.title(f'{metodo} - {hoja}', fontsize=18)
# #             plt.xlabel('Ciclo de marcha (%)', fontsize=15)
# #             plt.ylabel('Ángulo (°)', fontsize=15)
# #             plt.xticks(fontsize=12)
# #             plt.yticks(fontsize=12)
# #             plt.tight_layout()
# #             plt.grid(alpha=0.3)
# #             # plt.legend(fontsize=8, bbox_to_anchor=(1.01, 1), loc='upper left') # Si quieres ver los nombres
# #             nombre_png = f"{metodo}_{hoja}.png".replace("/", "_")
# #             plt.savefig(os.path.join(imgs_folder, nombre_png), dpi=200)
# #             plt.close()
# #     print(f"✅ Imágenes guardadas en: {imgs_folder}")

# # print("=== GRAFICANDO TODOS LOS CICLOS DE XSENS ===")
# # graficar_todos_por_hoja(file_xsens_todos, "XSENS")
# # print("=== GRAFICANDO TODOS LOS CICLOS DE 3DMA ===")
# # graficar_todos_por_hoja(file_3dma_todos, "3DMA")
# def graficar_todos_por_hoja(file_path, metodo):
#     imgs_folder = os.path.join(base_path, f'IMGS_CICLOS_TODOS_{metodo.upper()}')
#     os.makedirs(imgs_folder, exist_ok=True)
#     with pd.ExcelFile(file_path) as xls:
#         for hoja in xls.sheet_names:
#             df = pd.read_excel(xls, sheet_name=hoja)
#             ciclos = df.drop(columns=['Ciclo de marcha (%)'], errors='ignore')
#             t = df['Ciclo de marcha (%)'] if 'Ciclo de marcha (%)' in df else np.linspace(0, 100, NORM_POINTS)
#             plt.figure(figsize=(10, 5))
            
#             # Elige la paleta según el método
#             if metodo.upper() == "XSENS":
#                 # Paleta de rojos, más claros a más oscuros
#                 colors = [cm.Reds(0.4 + 0.6 * (i / max(1, len(ciclos.columns)-1))) for i in range(len(ciclos.columns))]
#             else:  # 3DMA
#                 # Paleta de grises (negros a gris claro)
#                 colors = [cm.Greys(0.4 + 0.6 * (i / max(1, len(ciclos.columns)-1))) for i in range(len(ciclos.columns))]

#             for col, color in zip(ciclos.columns, colors):
#                 plt.plot(t, ciclos[col], alpha=0.55, color=color)

#             plt.title(f'{metodo} - {hoja}', fontsize=18)
#             plt.xlabel('Ciclo de marcha (%)', fontsize=15)
#             plt.ylabel('Ángulo (°)', fontsize=15)
#             plt.xticks(fontsize=12)
#             plt.yticks(fontsize=12)
#             plt.tight_layout()
#             plt.grid(alpha=0.3)
#             # plt.legend(fontsize=8, bbox_to_anchor=(1.01, 1), loc='upper left') # Si quieres ver los nombres
#             nombre_png = f"{metodo}_{hoja}.png".replace("/", "_")
#             plt.savefig(os.path.join(imgs_folder, nombre_png), dpi=200)
#             plt.close()
#     print(f"✅ Imágenes guardadas en: {imgs_folder}")

# # Ejecución
# print("=== GRAFICANDO TODOS LOS CICLOS DE XSENS ===")
# graficar_todos_por_hoja(file_xsens_todos, "XSENS")
# print("=== GRAFICANDO TODOS LOS CICLOS DE 3DMA ===")
# graficar_todos_por_hoja(file_3dma_todos, "3DMA")

# try:
#     from similaritymeasures import frechet_dist
#     HAS_FRECHET = True
# except ImportError:
#     HAS_FRECHET = False
#     print("⚠️ similaritymeasures no está instalado. Se usará Hausdorff como alternativa para Fréchet.")

# === CONFIGURA TUS RUTAS ===
base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
file_xsens_copia = os.path.join(base_path, 'CICLOS_XSENS_COPIA.xlsx')
file_3dma_copia = os.path.join(base_path, 'CICLOS_3DMA_COPIA.xlsx')
imgs_path = os.path.join(base_path, "GRAFICAS_AURA")
os.makedirs(imgs_path, exist_ok=True)

ANGULOS = [
    'cadera_der_f_e', 'cadera_der_abd_add',
    'cadera_izq_f_e', 'cadera_izq_abd_add',
    'rodilla_der_f_e', 'rodilla_der_abd_add',
    'rodilla_izq_f_e', 'rodilla_izq_abd_add',
    'tobillo_der_f_e', 'tobillo_izq_f_e'
]
NORM_POINTS = 100

# === Qué criterio de alineación usar por ángulo ===
# Usa 'max' o 'min' según corresponda (modifica esto si quieres otro criterio por ángulo)
CRITERIO_ALINEACION = {
    'cadera_der_f_e': 'min',
    'cadera_der_abd_add': 'min',
    'cadera_izq_f_e': 'min',
    'cadera_izq_abd_add': 'min',
    'rodilla_der_f_e': 'max',
    'rodilla_der_abd_add': 'min',
    'rodilla_izq_f_e': 'max',
    'rodilla_izq_abd_add': 'min',
    'tobillo_der_f_e': 'min',
    'tobillo_izq_f_e': 'min'
}

def alinear_por_pico(x, y, tipo='max'):
    """
    Desplaza circularmente el ciclo 'y' para que su máximo/mínimo coincida con el de 'x'.
    tipo: 'max' o 'min'
    """
    if tipo == 'max':
        idx_x = np.argmax(x)
        idx_y = np.argmax(y)
    else:
        idx_x = np.argmin(x)
        idx_y = np.argmin(y)
    shift = idx_x - idx_y
    return np.roll(y, shift)

resultados = []

for angulo in ANGULOS:
    df_xsens = pd.read_excel(file_xsens_copia, sheet_name=angulo)
    df_3dma  = pd.read_excel(file_3dma_copia, sheet_name=angulo)
    
    # Extraer solo los nombres base (sin _DERECHO/_IZQUIERDO ni _ #...)
    xsens_bases = {}
    for col in df_xsens.columns:
        if col == "Ciclo de marcha (%)":
            continue
        # Elimina sufijo _DERECHO/_IZQUIERDO
        base = col.rsplit('_', 1)[0]
        xsens_bases[base] = col
    
    # Agrupa columnas de 3DMA por base
    from collections import defaultdict
    ciclos_3dma_grouped = defaultdict(list)
    for col in df_3dma.columns:
        if col == "Ciclo de marcha (%)":
            continue
        base = col.split('_ #')[0]  # Hasta antes de "_ #"
        ciclos_3dma_grouped[base].append(col)
    
    for base in xsens_bases:
        if base not in ciclos_3dma_grouped:
            continue  # No hay matching
        col_xsens = xsens_bases[base]
        cols_3dma = ciclos_3dma_grouped[base]
        # Promedia los ciclos de 3DMA para este sujeto/captura
        y_raw = df_3dma[cols_3dma].mean(axis=1).values
        x = df_xsens[col_xsens].values

        # Asegura que tengan la misma longitud
        if len(x) != len(y_raw):
            print(f"Longitudes distintas para {base}: XSENS {len(x)}, 3DMA {len(y_raw)}")
            continue

        # --- ALINEACIÓN por pico ---
        criterio = CRITERIO_ALINEACION.get(angulo, 'max')
        y = alinear_por_pico(x, y_raw, tipo=criterio)

        # --- Cálculo de métricas ---
        rmse = np.sqrt(np.mean((x - y) ** 2))
        try:
            pearson, _ = pearsonr(x, y)
        except Exception:
            pearson = np.nan
        t = np.linspace(0, 100, NORM_POINTS)
        xy1 = np.stack([t, x]).T
        xy2 = np.stack([t, y]).T
        if HAS_FRECHET:
            try:
                frechet = frechet_dist(xy1, xy2)
            except Exception:
                frechet = np.nan
        else:
            frechet = max(directed_hausdorff(xy1, xy2)[0], directed_hausdorff(xy2, xy1)[0])
        resultados.append({
            "sujeto_captura": base,
            "angulo": angulo,
            "rmse": rmse,
            "pearson": pearson,
            "frechet": frechet
        })

        if pearson > 0.7:
            std_3dma = df_3dma[cols_3dma].std(axis=1).values if len(cols_3dma) > 1 else np.zeros_like(y)
            cols_xsens = [col for col in df_xsens.columns if col.startswith(base)]
            std_xsens = df_xsens[cols_xsens].std(axis=1).values if len(cols_xsens) > 1 else np.zeros_like(x)

            plt.figure(figsize=(8, 4))
            # Curva promedio XSENS
            line_xsens, = plt.plot(t, x, label="XSENS", lw=2, color='#d03c34')
            plt.fill_between(t, x-std_xsens, x+std_xsens, color="#fcaaa6", alpha=0.3)
            # Curva promedio 3DMA
            line_3dma, = plt.plot(t, y, label="3DMA (alineado)", lw=2, color='#111111')
            plt.fill_between(t, y-std_3dma, y+std_3dma, color='#888888', alpha=0.3)

            plt.xlabel('Ciclo de marcha (%)', fontsize=12)
            plt.ylabel('Ángulo (°)', fontsize=12)
            plt.title(f"{base} - {angulo}", fontsize=15)
            plt.xticks(fontsize=11)
            plt.yticks(fontsize=11)
            plt.tight_layout()
            plt.grid(alpha=0.2)
            # Métricas dentro del gráfico (esquina superior izquierda)
            plt.text(
                0.01, 0.99,
                f"RMSE: {rmse:.2f}\nPearson: {pearson:.3f}\nFréchet: {frechet:.2f}",
                transform=plt.gca().transAxes,
                verticalalignment='top',
                horizontalalignment='left',
                fontsize=10,
                bbox=dict(facecolor='white', alpha=0.85, edgecolor="none")
            )
            # Solo los promedios en la leyenda, abajo derecha, letra pequeña
            plt.legend(
                handles=[line_xsens, line_3dma],
                fontsize=9,
                loc='lower right'
            )
            fname = f"{base}_{angulo}_pearson_gt08.png".replace("/", "_")
            plt.savefig(os.path.join(imgs_path, fname), dpi=200)
            plt.close()


# --- Organizar el DataFrame por sujeto (y dentro de sujeto por ángulo) ---
df_metrics = pd.DataFrame(resultados)
df_metrics = df_metrics.sort_values(['sujeto_captura', 'angulo'])
metrics_path = os.path.join(base_path, "METRICAS_INDIVIDUALES.xlsx")
df_metrics.to_excel(metrics_path, index=False)
print(f"\n✅ Métricas individuales guardadas en: {metrics_path}")
print(f"✅ Gráficas Pearson>0.8 guardadas en: {imgs_path}")


##### PROCESAMIENTO MÉTRICAS

base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
excel_file = os.path.join(base_path, 'METRICAS_INDIVIDUALES.xlsx')
df = pd.read_excel(excel_file)

# Diccionario de abreviaturas para los ángulos
abrev_angulos = {
    'cadera_der_f_e': 'Cad_D_FE',
    'cadera_der_abd_add': 'Cad_D_AA',
    'cadera_izq_f_e': 'Cad_L_FE',
    'cadera_izq_abd_add': 'Cad_L_AA',
    'rodilla_der_f_e': 'Rod_D_FE',
    'rodilla_der_abd_add': 'Rod_D_AA',
    'rodilla_izq_f_e': 'Rod_I_FE',
    'rodilla_izq_abd_add': 'Rod_I_AA',
    'tobillo_der_f_e': 'Tob_D_FE',
    'tobillo_izq_f_e': 'Tob_I_FE'
}

# Aplica las abreviaturas en la columna "angulo"
df['angulo_abrev'] = df['angulo'].map(abrev_angulos)


# RMSE
# pivot_rmse = df.pivot(index="angulo_abrev", columns="sujeto_captura", values="rmse")
# plt.figure()
# sns.heatmap(pivot_rmse, annot=True, cmap="Reds", fmt=".1f", cbar=True)
# plt.title("Mapa de calor RMSE (error cuadrático medio)")
# plt.xlabel("")
# plt.ylabel("Ángulo")
# plt.xticks([], [])  # Oculta los nombres de los sujetos/capturas
# plt.yticks(fontsize=11)  # Tamaño cómodo para las etiquetas
# plt.tight_layout()  # Más espacio a la izquierda
# plt.show()

# # Pearson
# pivot_pearson = df.pivot(index="angulo_abrev", columns="sujeto_captura", values="pearson")
# plt.figure()
# sns.heatmap(pivot_pearson, annot=True, cmap="Oranges", fmt=".2f", center=0, cbar=True)
# plt.title("Mapa de calor Pearson (correlación)")
# plt.xlabel("")
# plt.ylabel("Ángulo")
# plt.xticks([], [])
# plt.yticks(fontsize=11)
# plt.tight_layout()
# plt.show()

# # Fréchet
# pivot_frechet = df.pivot(index="angulo_abrev", columns="sujeto_captura", values="frechet")
# plt.figure()
# sns.heatmap(pivot_frechet, annot=True, cmap="Blues", fmt=".1f", cbar=True)
# plt.title("Mapa de calor Fréchet")
# plt.xlabel("")
# plt.ylabel("Ángulo")
# plt.xticks([], [])
# plt.yticks(fontsize=11)
# plt.tight_layout()
# plt.show()