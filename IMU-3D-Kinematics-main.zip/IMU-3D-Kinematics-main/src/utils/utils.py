import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation as R
from scipy.signal import find_peaks, butter, lfilter, correlate, windows, fftconvolve, butter, filtfilt, argrelextrema
from scipy.fftpack import fft, fftfreq
from sklearn.metrics import mean_squared_error
from scipy.ndimage import gaussian_filter1d

# =================== FUNCIONES PRINCIPALES =================== #


def buscar_archivo(directorio, nombre_parcial):
    archivos = [f for f in os.listdir(directorio) if nombre_parcial in f]
    if not archivos:
        raise FileNotFoundError(f"No se encontró el archivo para {nombre_parcial}")
    return os.path.join(directorio, archivos[0])


def cargar_datos(directorio, nombre_sensor):
    """Carga los archivos CSV de los sensores del muslo, la tibia y la pelvis."""
    path = buscar_archivo(directorio, nombre_sensor)
    read = pd.read_csv(path)
    return read


def cargar_datos_3dma(directorio_3dma, nombre_archivo_3dma):
    path_3dma = buscar_archivo(directorio_3dma, nombre_archivo_3dma)
    read = pd.read_csv(path_3dma, sep=';', decimal=',', encoding='utf-8')
    return read


# =================== PROCESAMIENTO DE CUATERNIONES =================== #

def cuaterniones_a_rotacion(qw, qx, qy, qz):
    """Convierte cuaterniones a matrices de rotación"""
    q = np.array([qw, qx, qy, qz])
    r = R.from_quat(q)
    rot = r.as_matrix()
    return rot

def corregir_signo_cuaterniones(quats):
    """
    Corrige la continuidad de los cuaterniones para evitar saltos de 180°.
    Si el producto punto entre cuats consecutivos es negativo, invierte el signo.
    
    Entrada:
        quats: np.array de forma (N, 4) con cuaterniones [w, x, y, z]
    
    Salida:
        np.array corregido de forma (N, 4)
    """
    quats_corr = [quats[0]]
    for i in range(1, len(quats)):
        if np.dot(quats_corr[-1], quats[i]) < 0:
            quats_corr.append(-quats[i])
        else:
            quats_corr.append(quats[i])
    return np.array(quats_corr)


def obtener_rotaciones(df):
    """
    Convierte columnas de cuaternión a matrices de rotación 3x3,
    corrigiendo continuidad de signos.
    """
    cuats = df[['Quat_W', 'Quat_X', 'Quat_Y', 'Quat_Z']].to_numpy()
    
    # Corregir la continuidad de los signos
    cuats_corr = corregir_signo_cuaterniones(cuats)

    # Convertir a rotaciones (SciPy usa orden [x, y, z, w])
    rotaciones = R.from_quat(cuats_corr[:, [0, 1, 2, 3]])
    
    return rotaciones.as_matrix()

def calcular_R_SB(rotaciones, n=400, usar_identidad=False):
    
    """Calcula la matriz promedio de la posicion de calibración: bípeda estática"""
    
    if usar_identidad:
        #Usa la matriz identidad como matriz R_SB: implica que no hay ninguna transformación
        return np.identity(3)

    #Saca un promedio de las 400 primeras matrices y calcula su promedio en svd 
    rot_matrices = np.array(rotaciones[:n])
    U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
    R = U @ Vt

    # Verifica si la matriz resultante es una reflexión (determinante -1)
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1
        R = U @ Vt

    return R

def calcular_R_SB_dinamico(rotaciones, ventana=400, usar_identidad=False):
    """
    Calcula R_SB dinámicamente como promedio de una ventana de rotaciones.
    """
    R_SB_list = []
    for i in range(len(rotaciones)):
        inicio = max(0, i - ventana)
        fin = i + 1
        rot_matrices = np.array(rotaciones[inicio:fin])
        U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
        R = U @ Vt
        if np.linalg.det(R) < 0:
            U[:, -1] *= -1
            R = U @ Vt
        R_SB_list.append(R)
    return R_SB_list

def transformar_rotacion(rotaciones, R_SB):
    """ Convierte del espacio geodésico ENU al espacio local del posicionamiento bípedo de los sensores"""
    #Usamos la matriz transpuesta para generar el cambio 
    local = [R_SB.T @ rot for rot in rotaciones]
    return local

def transformar_rotacion_dinamica(rotaciones, R_SB_list):
    return [R_SB_list[i].T @ rotaciones[i] for i in range(len(rotaciones))]

def alinear_senales(angulos_xsens, angulos_3dma, tiempo_120hz):
    picos_xsens, _ = find_peaks(angulos_xsens, height=np.percentile(angulos_xsens, 90))
    picos_3dma, _ = find_peaks(angulos_3dma, height=np.percentile(angulos_3dma, 90))

    if len(picos_xsens) == 0 or len(picos_3dma) == 0:
        print("No se detectaron suficientes picos para alinear las señales.")
        return angulos_3dma, tiempo_120hz

    desfase_tiempo = tiempo_120hz[picos_3dma[0]] - tiempo_120hz[picos_xsens[0]]
    tiempo_ajustado_3dma = tiempo_120hz - desfase_tiempo

    interp_func = interp1d(tiempo_ajustado_3dma, angulos_3dma, kind='linear', fill_value='extrapolate')
    angulos_3dma_alineados = interp_func(tiempo_120hz[:len(angulos_xsens)]) # Interpolar a la longitud de XSENS

    return angulos_3dma_alineados, tiempo_120hz[:len(angulos_xsens)]


### FILTROS 

def butter_pasaaltas(data, cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='high', analog=False)
    y = lfilter(b, a, data)
    return y

def filtro_pasabandas(datos, lowcut, highcut, fs, order=4):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return filtfilt(b, a, datos)









########## GIROS  ##########################

def encontrar_giros(tiempo, senal, picos, fs=120, seg_busqueda=1, umbral=50):
    """
    - Antes del pico: busca el punto de mayor gradiente positivo < umbral
    - Después del pico: busca el de mayor gradiente negativo < umbral
    """
    base_picos = {}
    for pico_idx in picos:
        # --- Base anterior ---
        idx_ini = max(0, pico_idx - int(seg_busqueda*fs))
        idx_fin = pico_idx
        tramo = senal[idx_ini:idx_fin]
        grad = np.gradient(tramo)
        # Encuentra todos los candidatos con valor < umbral
        candidatos = np.where(tramo < umbral)[0]
        if len(candidatos) > 0:
            # De esos, escoge el de mayor gradiente positivo
            idx_grad = np.argmax(grad[candidatos])
            idx_base_antes = idx_ini + candidatos[idx_grad]
        else:
            # Si ninguno cumple, usa el mayor gradiente
            idx_base_antes = idx_ini + np.argmax(grad)
        tiempo_base_antes = tiempo[idx_base_antes]

        # --- Base posterior ---
        idx_post_ini = pico_idx
        idx_post_fin = min(len(senal), pico_idx + int(seg_busqueda*fs))
        tramo_post = senal[idx_post_ini:idx_post_fin]
        grad_post = np.gradient(tramo_post)
        candidatos_post = np.where(tramo_post < umbral)[0]
        if len(candidatos_post) > 0:
            idx_grad_post = np.argmin(grad_post[candidatos_post])
            idx_base_post = idx_post_ini + candidatos_post[idx_grad_post]
        else:
            idx_base_post = idx_post_ini + np.argmin(grad_post)
        tiempo_base_post = tiempo[idx_base_post]

        base_picos[pico_idx] = (tiempo_base_antes, tiempo_base_post)
    return base_picos

def ventaneo(angulos):
    # Aplicar ventaneo hannning
    ventana = windows.hamming(len(angulos))
    signal_windowed = angulos * ventana

    return signal_windowed

def transformada_fourier(angulos_ventaneo, fs=120):
    # Computar FFT y establecer 120 Hz 
    fft_values = fft(angulos_ventaneo)
    fft_magnitude = np.abs(fft_values) / (len(angulos_ventaneo)/2)
    frequencies = fftfreq(len(angulos_ventaneo), d=1/fs) 

    # Keep positive frequencies only
    positive_freqs = frequencies[:len(frequencies)//2]
    positive_fft_magnitude = fft_magnitude[:len(frequencies)//2]
    
    return positive_freqs, positive_fft_magnitude