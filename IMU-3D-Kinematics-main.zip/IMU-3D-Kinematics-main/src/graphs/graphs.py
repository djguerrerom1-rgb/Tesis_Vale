import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import pearsonr

def graficar_angulos(angulos, datos_awinda):
    """Grafica la comparación de ángulos de rodilla entre Xsens y Awinda."""
    tiempo = np.linspace(0, 60, len(angulos))
    azul = "#006772"
    amarillo = "#c07c04"

    plt.figure(figsize=(15, 6))
    plt.plot(tiempo[0:200], angulos[0:200], label='F/E Rodilla Uniandes', color=azul)
    plt.plot(tiempo[0:200], datos_awinda[50:250], label='F/E Rodilla Awinda', color=amarillo)
    plt.xlabel('Tiempo (s)', fontsize=16)
    plt.ylabel('Ángulo (°)', fontsize=16)
    plt.legend(fontsize=16)
    plt.title('Comparación de ángulo de flexión/extensión Rodilla: Xsens vs Awinda', fontsize=16)
    plt.grid()
    plt.show()

def calcular_correlacion(angulos, datos_awinda):
    """Calcula la correlación entre los ángulos de Xsens y Awinda."""
    angulos_segmento = angulos[0:200]
    datos_awinda_segmento = datos_awinda[50:250]

    if len(angulos_segmento) == len(datos_awinda_segmento):
        correlacion, p_valor = pearsonr(angulos_segmento, datos_awinda_segmento)
        print(f"Coeficiente de correlación de Pearson: {correlacion:.3f}")
        print(f"P-valor: {p_valor:.3f}")
    else:
        print("Los datos no tienen la misma longitud para la correlación.")