import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation as R
from scipy.signal import find_peaks, butter, lfilter, correlate, windows, fftconvolve, butter, filtfilt, argrelextrema
from scipy.fftpack import fft, fftfreq
from sklearn.metrics import mean_squared_error
from scipy.ndimage import gaussian_filter1d
from scipy.signal import savgol_filter
#from src.utils.utils import (cargar_datos, cargar_datos_3dma, obtener_rotaciones, 
#                             calcular_R_SB, transformar_rotacion, alinear_senales)

# =================== FUNCIONES PRINCIPALES =================== #  

def cargar_datos(directorio, nombre_cadera, nombre_muslo):
    """Carga los archivos CSV de los sensores de la cadera y el muslo."""
    cadera_path = buscar_archivo(directorio, nombre_cadera)
    muslo_path = buscar_archivo(directorio, nombre_muslo)
    return pd.read_csv(cadera_path), pd.read_csv(muslo_path)


def buscar_archivo(directorio, nombre_parcial):
    archivos = [f for f in os.listdir(directorio) if nombre_parcial in f]
    if not archivos:
        raise FileNotFoundError(f"No se encontró el archivo para {nombre_parcial}")
    return os.path.join(directorio, archivos[0])


def cargar_datos_3dma(directorio_3dma, nombre_archivo_3dma):
    path_3dma = buscar_archivo(directorio_3dma, nombre_archivo_3dma)
    return pd.read_csv(path_3dma, sep=';', decimal=',', encoding='utf-8')

# =================== PROCESAMIENTO DE CUATERNIONES =================== #

def corregir_signo_cuaterniones(quats):
    """
    Corrige la continuidad de los cuaterniones para evitar saltos de 180°.
    Si el producto punto entre cuats consecutivos es negativo, invierte el signo.
    
    Entrada:
        quats: np.array de forma (N, 4) con cuaterniones [w, x, y, z]
    
    Salida:
        np.array corregido de forma (N, 4)
    """
    quats_corr = [quats[0]]
    for i in range(1, len(quats)):
        if np.dot(quats_corr[-1], quats[i]) < 0:
            quats_corr.append(-quats[i])
        else:
            quats_corr.append(quats[i])
    return np.array(quats_corr)


def obtener_rotaciones(df):
    """
    Convierte columnas de cuaternión a matrices de rotación 3x3,
    corrigiendo continuidad de signos.
    """
    cuats = df[['Quat_W', 'Quat_X', 'Quat_Y', 'Quat_Z']].to_numpy()
    
    # Corregir la continuidad de los signos
    cuats_corr = corregir_signo_cuaterniones(cuats)

    # Convertir a rotaciones (SciPy usa orden [x, y, z, w])
    rotaciones = R.from_quat(cuats_corr[:, [0, 1, 2, 3]])
    
    return rotaciones.as_matrix()

def cuaterniones_a_rotacion(df):
    """Convierte cuaterniones a matrices de rotación."""
    cuats = df[['Quat_W', 'Quat_X', 'Quat_Y', 'Quat_Z']].to_numpy()
    
    # Corregir la continuidad de los signos
    cuats_corr = corregir_signo_cuaterniones(cuats)

    # Convertir a rotaciones (SciPy usa orden [x, y, z, w])
    r = R.from_quat(cuats_corr[:, [0, 1, 2, 3]])
    return r.as_matrix()


def calcular_R_SB(rotaciones, n=400, usar_identidad=False):
    if usar_identidad:
        return np.identity(3)

    rot_matrices = np.array(rotaciones[:n])
    U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
    R = U @ Vt

    # Corrección si la matriz resultante es una reflexión (determinante -1)
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1
        R = U @ Vt

    return R

# def calcular_R_SB_dinamico(rotaciones, ventana=100, usar_identidad=False):
#     """
#     Calcula R_SB dinámicamente como promedio de una ventana de rotaciones.
#     """
#     R_SB_list = []
#     for i in range(len(rotaciones)):
#         inicio = max(0, i - ventana)
#         fin = i + 1
#         rot_matrices = np.array(rotaciones[inicio:fin])
#         U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
#         R = U @ Vt
#         if np.linalg.det(R) < 0:
#             U[:, -1] *= -1
#             R = U @ Vt
#         R_SB_list.append(R)
#     return R_SB_list

def calcular_R_SB_dinamico(rotaciones, ventana=500,usar_identidad=False):
    """
    Calcula R_SB dinámicamente como promedio de una ventana de rotaciones,
    alineando la base dinámica con la base estática al inicio y actualizando
    la estática de referencia.

    Parámetros:
    - rotaciones: lista de matrices de rotación (3x3).
    - R_estatico_inicial: matriz 3x3 de base anatómica estática inicial (calibración).
    - ventana: tamaño de ventana para suavizado (default = 120).

    Retorna:
    - Lista de matrices R_SB dinámicas ajustadas.
    """
    R_SB_list_raw = []
    R_estatico_inicial = calcular_R_SB(rotaciones, usar_identidad=usar_identidad)
    R_estatico_actual = R_estatico_inicial.copy() # Inicializa la estática actual

    # Paso 1: calcular las bases dinámicas (sin corrección aún)
    for i, rot in enumerate(rotaciones):
        inicio = max(0, i - ventana)
        fin = i + 1
        rot_matrices = np.array(rotaciones[inicio:fin])
        U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
        R_dinamico = U @ Vt
        if np.linalg.det(R_dinamico) < 0:
            U[:, -1] *= -1
            R_dinamico = U @ Vt
        R_SB_list_raw.append(R_dinamico)

        # Paso 2: calcular la rotación de corrección entre la dinámica y la estática actual
        R_correccion = R_estatico_actual @ R_dinamico.T

        # Paso 3: aplicar la corrección a la matriz dinámica
        R_SB_ajustada = R_correccion @ R_dinamico
        R_SB_list_raw[i] = R_SB_ajustada # Actualiza el valor en la lista

        # Paso 4: actualizar la estática de referencia cada cierto número de frames
        if (i + 1) % ventana == 0:  # Actualizar cada ventana
            R_estatico_actual = R_dinamico # La estatica se vuelve la dinamica

    return R_SB_list_raw

# def calcular_R_SB_dinamico(rotaciones, ventana=120, usar_identidad= False):
#     """
#     Calcula R_SB dinámicamente como promedio de una ventana de rotaciones,
#     alineando la base dinámica con la base estática al inicio.
    
#     Parámetros:
#     - rotaciones: lista de matrices de rotación (3x3).
#     - R_estatico: matriz 3x3 de base anatómica estática (calibración).
#     - ventana: tamaño de ventana para suavizado (default = 100).
    
#     Retorna:
#     - Lista de matrices R_SB dinámicas ajustadas.
#     """
#     R_SB_list_raw = []
#     R_estatico = calcular_R_SB(rotaciones, usar_identidad=usar_identidad)

#     Paso 1: calcular las bases dinámicas (sin corrección aún)
#     for i in range(len(rotaciones)):
#         inicio = max(0, i - ventana)
#         fin = i + 1
#         rot_matrices = np.array(rotaciones[inicio:fin])
#         U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
#         R = U @ Vt
#         if np.linalg.det(R) < 0:
#             U[:, -1] *= -1
#             R = U @ Vt
#         R_SB_list_raw.append(R)

#     Paso 2: calcular la rotación de corrección entre la dinámica inicial y la estática
#     R_dinamico_0 = R_SB_list_raw[0]
#     R_correccion = R_estatico @ R_dinamico_0.T

#     Paso 3: aplicar la corrección a todas las matrices
#     R_SB_list_ajustada = [R_correccion @ R for R in R_SB_list_raw]

#     return R_SB_list_ajustada


def transformar_rotacion_dinamica(rotaciones, R_SB_list):
    return [R_SB_list[i].T @ rotaciones[i] for i in range(len(rotaciones))]

# Se reconstruye la matriz de rotación válida en el espacio de Riemann
def transformar_rotacion(rotaciones, R_SB):
    """ Convierte del espacio geodésico ENU al espacio local del posicionamiento bípedo de los sensores"""
    #Usamos la matriz transpuesta para generar el cambio 
    local = [R_SB.T @ rot for rot in rotaciones]
    return local


#######  CALCULAR ANGULOS ################

def flex_ext_cadera(rot_pelvis, rot_muslo, R_SB_pelvis, R_SB_muslo):
    muslo_local = transformar_rotacion(rot_muslo, R_SB_muslo)
    pelvis_local = transformar_rotacion(rot_pelvis, R_SB_pelvis)
    fe = []
    for i in range(len(rot_pelvis)):
        R_rmuslo = pelvis_local[i].T @ muslo_local[i]
        # flexion_extension = np.degrees(np.arctan2(z_muslo_rel[0], z_muslo_rel[2]))
        flexion_extension = np.degrees(np.arctan2(R_rmuslo[2, 2], R_rmuslo[0, 2]))
        fe.append(flexion_extension)
    fe = np.array(fe)
    fe -= fe[0]  # Centrar en cero
    return fe


def abduccion_adduccion_cadera(rot_pelvis, rot_muslo, R_SB_pelvis, R_SB_muslo):
    muslo_local = transformar_rotacion(rot_muslo, R_SB_muslo)
    pelvis_local = transformar_rotacion(rot_pelvis, R_SB_pelvis)
    aa = []
    for i in range(len(rot_pelvis)):
        R_rmuslo = pelvis_local[i].T @ muslo_local[i]
        abduccion_adduccion = np.degrees(np.arctan2(-R_rmuslo[0, 1], R_rmuslo[1, 1]))
        aa.append(abduccion_adduccion)
    aa = np.array(aa)
    aa -= aa[0]  # Centrar en cero
    return aa


def rot_int_ext_cadera(rot_pelvis, rot_muslo, R_SB_pelvis, R_SB_muslo):
    muslo_local = transformar_rotacion(rot_muslo, R_SB_muslo)
    pelvis_local = transformar_rotacion(rot_pelvis, R_SB_pelvis)
    rie = []
    for i in range(len(rot_pelvis)):
        R_rmuslo = pelvis_local[i].T @ muslo_local[i]
        rotacion_interna_externa = np.degrees(np.arctan2(R_rmuslo[1, 0], R_rmuslo[1, 1]))
        rie.append(rotacion_interna_externa)
    rie = np.array(rie)
    rie -= rie[0]  # Centrar en cero
    return rie


# =================== PROCESAMIENTO PRINCIPAL =================== #


def ventaneo(angulos):
    # Aplicar ventaneo hannning
    ventana = windows.hamming(len(angulos))
    signal_windowed = angulos * ventana

    return signal_windowed

def transformada_fourier(angulos_ventaneo, fs=120):
    # Computar FFT y establecer 120 Hz 
    fft_values = fft(angulos_ventaneo)
    fft_magnitude = np.abs(fft_values) / (len(angulos_ventaneo)/2)
    frequencies = fftfreq(len(angulos_ventaneo), d=1/fs) 

    # Keep positive frequencies only
    positive_freqs = frequencies[:len(frequencies)//2]
    positive_fft_magnitude = fft_magnitude[:len(frequencies)//2]
    
    return positive_freqs, positive_fft_magnitude

def filtro_pasabandas(datos, lowcut, highcut, fs, order=4):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return filtfilt(b, a, datos)

def filter_window_threshold(angulos_xsens, lowcut, highcut, fs, threshold=0):
    filtered = filtro_pasabandas(angulos_xsens, lowcut, highcut, fs)
    windowed = ventaneo(filtered)
    transformed = np.where(windowed < threshold, np.abs(windowed), windowed)
    return transformed

def alinear_senales(angulos_xsens, angulos_3dma, tiempo_120hz):
    # Detectar picos usando el percentil 90 como umbral de altura
    picos_xsens, _ = find_peaks(angulos_xsens, height=np.percentile(angulos_xsens, 90))
    picos_3dma, _ = find_peaks(angulos_3dma, height=np.percentile(angulos_3dma, 90))

    # Validación de detección de picos
    if len(picos_xsens) == 0 or len(picos_3dma) == 0:
        print("⚠️ No se detectaron suficientes picos para alinear las señales.")
        return angulos_3dma, tiempo_120hz

    # Obtener el desfase de tiempo entre los primeros picos
    desfase_tiempo = tiempo_120hz[picos_3dma[0]] - tiempo_120hz[picos_xsens[0]]

    # Ajustar el tiempo de la señal 3DMA
    tiempo_ajustado_3dma = tiempo_120hz - desfase_tiempo

    # Interpolación de la señal 3DMA para que coincida con el tiempo de XSENS
    interp_func = interp1d(tiempo_ajustado_3dma, angulos_3dma, kind='linear', fill_value='extrapolate')
    angulos_3dma_alineados = interp_func(tiempo_120hz[:len(angulos_xsens)])

    return angulos_3dma_alineados, tiempo_120hz[:len(angulos_xsens)]


def preprocesamiento_mocap(angulos_3DMA):
    fs=120 #Hz
    #Aplicar ventaneo a los datos
    # Convertir la Serie de Pandas a un array de NumPy
    angulos_np = angulos_3DMA.values
    vent = ventaneo(angulos_np)
    fou = transformada_fourier(vent, fs=120)
    mocap_filtered = filtro_pasabandas(angulos_np, 0.3, 3, fs)
    
    return mocap_filtered


def encontrar_giros(tiempo, senal, picos, fs=120, seg_busqueda=1, umbral=50):
    """
    - Antes del pico: busca el punto de mayor gradiente positivo < umbral
    - Después del pico: busca el de mayor gradiente negativo < umbral
    """
    base_picos = {}
    for pico_idx in picos:
        # --- Base anterior ---
        idx_ini = max(0, pico_idx - int(seg_busqueda*fs))
        idx_fin = pico_idx
        tramo = senal[idx_ini:idx_fin]
        grad = np.gradient(tramo)
        # Encuentra todos los candidatos con valor < umbral
        candidatos = np.where(tramo < umbral)[0]
        if len(candidatos) > 0:
            # De esos, escoge el de mayor gradiente positivo
            idx_grad = np.argmax(grad[candidatos])
            idx_base_antes = idx_ini + candidatos[idx_grad]
        else:
            # Si ninguno cumple, usa el mayor gradiente
            idx_base_antes = idx_ini + np.argmax(grad)
        tiempo_base_antes = tiempo[idx_base_antes]

        # --- Base posterior ---
        idx_post_ini = pico_idx
        idx_post_fin = min(len(senal), pico_idx + int(seg_busqueda*fs))
        tramo_post = senal[idx_post_ini:idx_post_fin]
        grad_post = np.gradient(tramo_post)
        candidatos_post = np.where(tramo_post < umbral)[0]
        if len(candidatos_post) > 0:
            idx_grad_post = np.argmin(grad_post[candidatos_post])
            idx_base_post = idx_post_ini + candidatos_post[idx_grad_post]
        else:
            idx_base_post = idx_post_ini + np.argmin(grad_post)
        tiempo_base_post = tiempo[idx_base_post]

        base_picos[pico_idx] = (tiempo_base_antes, tiempo_base_post)
    return base_picos


def invertir_tramos_pares(angulos_xsens, giroscopio, fs=120, sigma=6, prominencia_picos=150):
    """
    Invierte los tramos pares de la señal de ángulo de cadera usando picos del giroscopio.
    Solo modifica la señal cruda, sin graficar ni normalizar.
    """
    n_muestras = len(angulos_xsens)
    giroscopio_suavizado = gaussian_filter1d(giroscopio, sigma=sigma)
    picos_giroscopio, _ = find_peaks(giroscopio_suavizado, prominence=prominencia_picos)
    picos_con_inicio_fin = np.concatenate(([0], picos_giroscopio, [n_muestras - 1]))

    angulos_xsens_ajustados = np.copy(angulos_xsens)
    for i in range(0, len(picos_con_inicio_fin) - 1):
        inicio = picos_con_inicio_fin[i]
        fin = picos_con_inicio_fin[i + 1]
        if (i + 1) % 2 == 0:
            angulos_xsens_ajustados[inicio:fin] *= -1

    return angulos_xsens_ajustados


def preprocesamiento_cadera(angulos_xsens, angulos_3DMA, giroscopio):
    fs = 120  # Hz
    t = np.arange(len(angulos_xsens)) / fs
    n_muestras = len(angulos_xsens)

    sigma = 6  # Ajusta este valor para controlar la cantidad de suavizado
    giroscopio_suavizado = gaussian_filter1d(giroscopio, sigma=sigma)

    picos_giroscopio, _ = find_peaks(giroscopio_suavizado, prominence=150)  # Ajusta la prominencia si es necesario

    umbral_velocidad = 75
    base_picos_giro = encontrar_giros(t, giroscopio_suavizado, picos_giroscopio, fs=120, seg_busqueda=1, umbral =75)


    # Invertir tramos pares de la señal de cadera
    angulos_xsens_ajustados = np.copy(angulos_xsens)
    picos_con_inicio_fin = np.concatenate(([0], picos_giroscopio, [n_muestras - 1]))

    for i in range(0, len(picos_con_inicio_fin) - 1):
        inicio = picos_con_inicio_fin[i]
        fin = picos_con_inicio_fin[i + 1]
        if (i + 1) % 2 == 0:
            angulos_xsens_ajustados[inicio:fin] *= -1

    # # Filtro pasabandas y normalización
    # min_orig = np.min(angulos_xsens)
    # max_orig = np.max(angulos_xsens)
    # xsens_filtrada = filtro_pasabandas(angulos_xsens, 0.5, 4.5, fs)
    # xsens_filtrada = (xsens_filtrada - np.min(xsens_filtrada)) / (np.max(xsens_filtrada) - np.min(xsens_filtrada))
    # xsens_filtrada = xsens_filtrada * (max_orig - min_orig) + min_orig
    # vent_xsens = ventaneo(xsens_filtrada) 
    # fou_xsens = transformada_fourier(vent_xsens, fs=fs)

    # # Señal de referencia MOCAP
    # mocap_original = angulos_3DMA[columna_fe_3dma].values
    # mocap_procesada = preprocesamiento_mocap(angulos_3DMA[columna_fe_3dma])
    # tiempo_mocap_original = np.arange(len(mocap_original)) / 240
    # tiempo_xsens = np.arange(len(angulos_xsens_ajustados)) / fs
    # interp_func_mocap = interp1d(tiempo_mocap_original, mocap_procesada, kind='linear', fill_value='extrapolate')
    # mocap_interpolada = interp_func_mocap(tiempo_xsens)

    # # Cálculo de error medio
    # mse_antes = mean_squared_error(mocap_interpolada, angulos_xsens)
    # mse_desp = mean_squared_error(mocap_interpolada, xsens_filtrada)
    # mse_invertida = mean_squared_error(mocap_interpolada, angulos_xsens_ajustados)

    # Preparar datos para graficar bases de picos
    tiempos_base_antes = [base[0] for _, base in base_picos_giro.items() if base[0] is not None]
    tiempos_base_despues = [base[1] for _, base in base_picos_giro.items() if base[1] is not None]

    valores_cadera_base_antes = [angulos_xsens_ajustados[int(t * fs)] for t in tiempos_base_antes]
    valores_cadera_base_despues = [angulos_xsens_ajustados[int(t * fs)] for t in tiempos_base_despues]
    tiempo_giroscopio = np.arange(len(giroscopio)) / fs
    valores_cadera_picos = angulos_xsens_ajustados[picos_giroscopio]

    # # Gráficas
    # fig, axs = plt.subplots(3, 2, figsize=(20, 15))

    # axs[0, 0].plot(t, angulos_xsens)
    # axs[0, 0].set_title("Señal de ángulos original (Inicial)")
    # axs[0, 0].set_xlabel('Tiempo [s]')
    # axs[0, 0].set_ylabel('Ángulo [°]')

    # axs[0, 1].plot(fou_xsens[0], fou_xsens[1])
    # axs[0, 1].set_title("FFT Spectro - XSENS")
    # axs[0, 1].set_xlim(0, 10)
    # axs[0, 1].set_xlabel("Frecuencia [Hz]")
    # axs[0, 1].set_ylabel("Amplitud")
    # axs[0, 1].set_xticks(np.arange(0, 10.1, 0.5))

    # axs[1, 0].plot(t, angulos_xsens_ajustados, label=f"Invertida (MSE: {mse_invertida:.4f})", alpha=0.8)
    # axs[1, 0].scatter(tiempos_base_antes, valores_cadera_base_antes, color='green', marker='x', label='Base Anterior (Cadera)')
    # axs[1, 0].scatter(tiempo_giroscopio[picos_giroscopio], valores_cadera_picos, color='red', marker='o', label='Picos (Cadera)')
    # axs[1, 0].scatter(tiempos_base_despues, valores_cadera_base_despues, color='blue', marker='+', label='Base Posterior (Cadera)')
    # axs[1, 0].set_title("Cadera (Tramos Pares Invertidos)")
    # axs[1, 0].set_xlabel("Tiempo [s]")
    # axs[1, 0].set_ylabel('Ángulo [°]')
    # axs[1, 0].legend()

    # axs[1, 1].plot(tiempo_giroscopio, giroscopio_suavizado, label=f'Gyr_X Suavizado (sigma={sigma})', color='orange')
    # axs[1, 1].scatter(tiempo_giroscopio[picos_giroscopio], giroscopio_suavizado[picos_giroscopio], color='red', marker='o', label='Picos de Giro (Suavizado)')
    # axs[1, 1].scatter(tiempos_base_antes, [giroscopio_suavizado[int(t * fs)] for t in tiempos_base_antes], color='green', marker='x', label=f'Base Anterior (<{umbral_velocidad} deg/s)')
    # axs[1, 1].scatter(tiempos_base_despues, [giroscopio_suavizado[int(t * fs)] for t in tiempos_base_despues], color='blue', marker='+', label='Base Posterior (Mínimo)')
    # axs[1, 1].set_title(f"Giroscopio Pelvis (Gyr_X) con Picos y Base (Umbral Anterior <{umbral_velocidad})")
    # axs[1, 1].set_xlabel("Tiempo [s]")
    # axs[1, 1].set_ylabel("Velocidad Angular [deg/s]")
    # axs[1, 1].legend()

    # axs[2, 0].plot(t, xsens_filtrada)
    # axs[2, 0].set_title("Filtro Pasabandas (0.5–4 Hz) - XSENS")
    # axs[2, 0].set_xlabel("Tiempo [s]")
    # axs[2, 0].set_ylabel('Ángulo [°]')

    # axs[2, 1].plot(t, angulos_xsens_ajustados, label=f"Original (MSE: {mse_antes:.4f})", alpha=0.6)
    # axs[2, 1].plot(t, xsens_filtrada, label=f"Filtrada (MSE: {mse_desp:.4f})", alpha=0.8)
    # axs[2, 1].set_title("Comparación con Referencia (Original)")
    # axs[2, 1].legend()
    # axs[2, 1].set_xlabel("Tiempo [s]")
    # axs[2, 1].set_ylabel('Ángulo [°]')
    # axs[2, 1].set_ylim(-40, 40)

    # plt.tight_layout()
    # plt.show()
    

    return angulos_xsens_ajustados

# =================== GRAFICADO INDIVIDUAL =================== #

def graficar_angulos_cadera(angulos, tiempo):
    
    """Grafica los ángulos de la cadera."""
    plt.figure(figsize=(12, 6))
    #plt.plot(tiempo[0:4000], angulos[:, 0][0:4000], label='Flexión/Extensión', color='red')
    #plt.plot(tiempo[0:4000], angulos[:, 1][0:4000], label='Abducción/Aducción', color='green')
    plt.plot(tiempo[0:4000], angulos[:, 2][0:4000], label='Rotación Interna/Externa', color='blue')
    #plt.plot(tiempo[0:2000], angulos[:, 3][0:2000], label='F\E sin rotar', color='black')
    plt.title('Ángulos de Cadera')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Ángulo (°)')
    plt.legend()
    plt.grid(True)
    plt.show()
# =================== PROCESAMIENTO PRINCIPAL =================== #

def procesar_datos_cadera(directorio, nombre_muslo, nombre_pelvis, usar_identidad=False):
    pelvis_data, muslo_data = cargar_datos(directorio, nombre_pelvis, nombre_muslo)
    min_length = min(len(muslo_data), len(pelvis_data))
    muslo_data = muslo_data[:min_length]
    pelvis_data = pelvis_data[:min_length]

    rot_muslo = obtener_rotaciones(muslo_data)
    rot_pelvis = obtener_rotaciones(pelvis_data)
    giroscopio = pelvis_data['Gyr_X'].values

    R_SB_muslo = calcular_R_SB(rot_muslo, usar_identidad=usar_identidad)
    R_SB_pelvis = calcular_R_SB(rot_pelvis, usar_identidad=usar_identidad)

    fe = flex_ext_cadera(rot_pelvis, rot_muslo, R_SB_pelvis, R_SB_muslo)
    aa = abduccion_adduccion_cadera(rot_pelvis, rot_muslo, R_SB_pelvis, R_SB_muslo)
    rie = rot_int_ext_cadera(rot_pelvis, rot_muslo, R_SB_pelvis, R_SB_muslo)

    angulos_xsens = np.vstack([fe, aa, rie]).T  # Shape (N, 3)

    # ----------- INVIERTE TRAMOS PARES (igual que antes) ----------
    fs = 120  # Hz
    sigma = 6
    giroscopio_suavizado = gaussian_filter1d(giroscopio, sigma=sigma)
    picos_giroscopio, _ = find_peaks(giroscopio_suavizado, prominence=150)
    n_muestras = len(angulos_xsens)
    picos_con_inicio_fin = np.concatenate(([0], picos_giroscopio, [n_muestras - 1]))
    angulos_xsens_ajustados = np.copy(angulos_xsens)
    for i in range(0, len(picos_con_inicio_fin) - 1):
        inicio = picos_con_inicio_fin[i]
        fin = picos_con_inicio_fin[i + 1]
        if (i + 1) % 2 == 0:
            angulos_xsens_ajustados[inicio:fin, :] *= -1
                   
    # --------- Restar bias (mediana) a cada columna ---------
    bias = np.median(angulos_xsens_ajustados, axis=0)  # (3,)
    angulos_xsens_ajustados -= bias
    
        # --------- Suavizado Savitzky-Golay SOLO en flexión/extensión (columna 0) ---------
    # Puedes ajustar window_length y polyorder según resultados
    # window_length = 53   # Debe ser impar y menor que n_muestras
    # polyorder = 3
    # angulos_xsens_ajustados_suave = np.copy(angulos_xsens_ajustados)
    # angulos_xsens_ajustados_suave[:, 0] = savgol_filter(angulos_xsens_ajustados[:, 0], window_length=window_length, polyorder=polyorder)
    sigma = 4  # Puedes ajustar el valor

    # Crea una copia de la matriz para no modificar el original
    angulos_xsens_ajustados_suave = np.copy(angulos_xsens_ajustados)

    # Aplica el filtro gaussiano a cada columna
    for i in range(angulos_xsens_ajustados.shape[1]):
        angulos_xsens_ajustados_suave[:, i] = gaussian_filter1d(angulos_xsens_ajustados[:, i], sigma=sigma)
        
    # --------- CENTRAR EN CERO (valor inicial de cada columna) ---------
    for i in range(angulos_xsens_ajustados_suave.shape[1]):
        angulos_xsens_ajustados_suave[:, i] -= angulos_xsens_ajustados_suave[0, i]

    # Devuelve el resultado suavizado
    return angulos_xsens_ajustados_suave, giroscopio




# # R_SB_pelvis, R_SB_muslo

# # Colors
# rojo="#c83d34"
# amarillo="#e7a347"

# # Función para graficar comparación
# def graficar_comparacion(tiempo, xsens_data, data_3dma, color_linea=rojo, color_ref=amarillo):
#     plt.figure(figsize=(12, 5))
#     plt.plot(tiempo[:4000], xsens_data[:4000], label='XSENS', color=color_linea)
#     plt.plot(tiempo[:4000], data_3dma[:4000], label='3DMA (Interpolado)', color=color_ref)
#     plt.title(f'Comparación F/E cadera XSENS VS 3DMA')
#     plt.xlabel('Tiempo (s)')
#     plt.ylabel('Ángulo (°)')
#     plt.legend()
#     plt.grid(True)
#     plt.show()
    
    
    

# # # =================== EJECUCIÓN =================== #
# # ====== TU PIPELINE DE COMPARACIÓN ======
# base_dir = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\Camila_Grazziani'
# ruta_xsens = os.path.join(base_dir, 'XSENS', 'XSENS_CUATERNIONES', '2')
# ruta_3dma = os.path.join(base_dir, '3DMA', '2')

# # 1. Procesar datos XSENS
# angulos_xsens, giroscopio_pelvis = procesar_datos_cadera(ruta_xsens, 'muslo_izq', 'pelvis', usar_identidad=False)

# # Guarda la señal antes del suavizado si la quieres comparar
# # angulos_xsens_original = ... # Si puedes, guárdala en tu función antes del filtro y devuélvela, o guárdala antes de suavizar.
# # Si no tienes la original, puedes solo comparar XSENS (suavizado) y 3DMA.

# # 2. Preprocesar datos 3DMA
# columna_fe_3dma = 'Left Hip Flexion/Extension::Y'
# hip_3dma_data = cargar_datos_3dma(ruta_3dma, 'hip angles.csv')

# # Interpolación 3DMA de 240Hz a 120Hz para comparar
# tiempo_3dma = np.linspace(0, len(hip_3dma_data) / 240, len(hip_3dma_data))
# interpolador = interp1d(tiempo_3dma, hip_3dma_data[columna_fe_3dma], fill_value='extrapolate')

# tiempo_120hz = np.linspace(0, len(angulos_xsens[:, 0]) / 120, len(angulos_xsens[:, 0]))
# hip_3dma_interpolado = interpolador(tiempo_120hz)

# # Alinear señales
# hip_3dma_alineado, tiempo_ajustado = alinear_senales(angulos_xsens[:, 0], hip_3dma_interpolado, tiempo_120hz)
# hip_3dma_inicial = hip_3dma_alineado[0]
# hip_3dma_centrado =  hip_3dma_alineado - hip_3dma_inicial

# # Graficar comparación
# graficar_comparacion(
#     tiempo_120hz, 
#     angulos_xsens[:, 0],          # XSENS suavizado (Flex/Ext)
#     hip_3dma_centrado        # 3DMA centrado y alinead
# )