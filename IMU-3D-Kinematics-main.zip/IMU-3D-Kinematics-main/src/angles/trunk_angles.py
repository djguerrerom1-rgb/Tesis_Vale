import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation as R
from scipy.signal import find_peaks, medfilt
from scipy.ndimage import gaussian_filter1d

# =================== FUNCIONES PRINCIPALES =================== #  

def cargar_datos(directorio, nombre_torso):
    pelvis_path = buscar_archivo(directorio, nombre_torso)
    return pd.read_csv(pelvis_path)

def buscar_archivo(directorio, nombre_parcial):
    archivos = [f for f in os.listdir(directorio) if nombre_parcial in f]
    if not archivos:
        raise FileNotFoundError(f"No se encontró el archivo para {nombre_parcial}")
    return os.path.join(directorio, archivos[0])


def cargar_datos_3dma(directorio_3dma, nombre_archivo_3dma):
    path_3dma = buscar_archivo(directorio_3dma, nombre_archivo_3dma)
    return pd.read_csv(path_3dma, sep=';', decimal=',', encoding='utf-8')

# =================== PROCESAMIENTO DE CUATERNIONES =================== #

def cuaterniones_a_rotacion(qw, qx, qy, qz):
    """Convierte cuaterniones a matrices de rotación."""
    q = np.array([qw, qx, qy, qz])
    r = R.from_quat(q)
    return r.as_matrix()

def corregir_signo_cuaterniones(quats):
    """
    Corrige la continuidad de los cuaterniones para evitar saltos de 180°.
    Si el producto punto entre cuats consecutivos es negativo, invierte el signo.
    
    Entrada:
        quats: np.array de forma (N, 4) con cuaterniones [w, x, y, z]
    
    Salida:
        np.array corregido de forma (N, 4)
    """
    quats_corr = [quats[0]]
    for i in range(1, len(quats)):
        if np.dot(quats_corr[-1], quats[i]) < 0:
            quats_corr.append(-quats[i])
        else:
            quats_corr.append(quats[i])
    return np.array(quats_corr)


def obtener_rotaciones(df):
    """
    Convierte columnas de cuaternión a matrices de rotación 3x3,
    corrigiendo continuidad de signos.
    """
    cuats = df[['Quat_W', 'Quat_X', 'Quat_Y', 'Quat_Z']].to_numpy()
    
    # Corregir la continuidad de los signos
    cuats_corr = corregir_signo_cuaterniones(cuats)

    # Convertir a rotaciones (SciPy usa orden [x, y, z, w])
    rotaciones = R.from_quat(cuats_corr[:, [0, 1, 2, 3]])
    
    return rotaciones.as_matrix()


def calcular_R_SB(rotaciones, n=400, usar_identidad=False):
    if usar_identidad:
        return np.identity(3)

    rot_matrices = np.array(rotaciones[:n])
    U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
    R = U @ Vt

    # Corrección si la matriz resultante es una reflexión (determinante -1)
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1
        R = U @ Vt

    return R

# Se reconstruye la matriz de rotación válida en el espacio de Riemann
def transformar_rotacion(rotaciones, R_SB):
    return [R_SB.T @ rot for rot in rotaciones]


# def calcular_angulos_torso(rot_torso, R_SB_torso): 
#     """Calcula los ángulos de pelvic tilt, pelvic obliquity and pelvic rotation """
#     angulos_torso = []
#     #Desde ENU to local frame
#     torso_local = transformar_rotacion(rot_torso, R_SB_torso)
    
#     for i in range(len(rot_torso)): # Se itera a traves de los indices
#         R_pelvis_matrix = rot_torso[i]
#         # Convertir la matriz de rotación NumPy a un objeto Rotation
#         R_pelvis_rot = R.from_matrix(R_pelvis_matrix)
#         # Convertir a ángulos de Euler (en grados), usando ZYX
#         euler_pelvis = R_pelvis_rot.as_euler('ZYX', degrees=True)
        
#         # Ángulos de movimiento del torso (siguiendo la convención de ángulos de Euler - Cardan)
#         obliq = euler_pelvis[0]   # rotación axial
#         tilt  = euler_pelvis[1]   # inclinación anterior/posterior
#         rotation = euler_pelvis[2]   # oblicuidad

#         angulos_torso.append([tilt, obliq, rotation])
#         #print('Despues de rotar muslo a torso', R_muslo_pelvis)
#     angulos_torso = np.array(angulos_torso)

#     # Centrar los ángulos en 0
#     angulos_torso -= angulos_torso[0]

#     return angulos_torso

def calcular_tilt_torso(rot_torso, R_SB_torso):
    torso_local = transformar_rotacion(rot_torso, R_SB_torso)
    tilt = [np.degrees(np.arctan2(R_t[2, 0], R_t[0, 0])) for R_t in torso_local]
    tilt = np.array(tilt)
    tilt -= tilt[0]
    return tilt

def calcular_obliquity_torso(rot_torso, R_SB_torso):
    torso_local = transformar_rotacion(rot_torso, R_SB_torso)
    obliquity = [np.degrees(np.arctan2(R_t[1, 0], R_t[0, 0])) for R_t in torso_local]
    obliquity = np.array(obliquity)
    obliquity -= obliquity[0]
    return obliquity

def calcular_rotation_torso(rot_torso, R_SB_torso):
    torso_local = transformar_rotacion(rot_torso, R_SB_torso)
    rotation = [np.degrees(np.arctan2(R_t[0, 1], R_t[1, 1])) for R_t in torso_local]
    rotation = np.array(rotation)
    rotation -= rotation[0]
    return rotation


def graficar_angulos_torso(angulos, tiempo):
    """Grafica los ángulos del torso"""
    plt.figure(figsize=(12, 6))
    #plt.plot(tiempo, angulos[:, 0], label='Torso Tilt', color='green')
    #plt.plot(tiempo, angulos[:, 1], label='Torso Obliquity', color='red')
    plt.plot(tiempo, angulos[:, 2], label='Torso Rotation', color='blue')
    
    # # Aplicar filtro Gaussiano a tilt
    # sigma_tilt = 50  # Ajusta este valor para controlar el nivel de suavizado
    # pelvic_tilt_original = angulos[:, 1]
    # pelvic_tilt_suavizado = gaussian_filter1d(pelvic_tilt_original, sigma=sigma_tilt)
    # #plt.plot(tiempo[0:4000], pelvic_tilt_suavizado[0:4000], label='Pelvic Tilt Suavizado', color='black')
    
    # # Aplicar filtro Gaussiano a Obliquity
    # sigma_ob = 7  # Ajusta este valor para controlar el nivel de suavizado
    # pelvic_ob_original = angulos[:, 0]
    # pelvic_ob_med = medfilt(pelvic_ob_original, kernel_size=17)
    # pelvic_ob_suavizado = gaussian_filter1d(pelvic_ob_med, sigma=sigma_ob)
    
    # plt.plot(tiempo[0:4000], pelvic_ob_med[0:4000], label='Pelvic Obliquity Median', color='green')
    # plt.plot(tiempo[0:4000], pelvic_ob_suavizado[0:4000], label='Pelvic Obliquity GAUSSIAN', color='black')
    
    
    plt.title('Ángulos del torso')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Ángulo (°)')
    #plt.ylim(-20,20)
    plt.legend()
    plt.grid(True)
    plt.show()
# =================== PROCESAMIENTO PRINCIPAL =================== #

def alinear_senales(angulos_xsens, angulos_3dma, tiempo_120hz):
    # Detectar picos usando el percentil 90 como umbral de altura
    picos_xsens, _ = find_peaks(angulos_xsens, height=np.percentile(angulos_xsens, 90))
    picos_3dma, _ = find_peaks(angulos_3dma, height=np.percentile(angulos_3dma, 90))

    # Validación de detección de picos
    if len(picos_xsens) == 0 or len(picos_3dma) == 0:
        print("⚠️ No se detectaron suficientes picos para alinear las señales.")
        return angulos_3dma, tiempo_120hz

    # Obtener el desfase de tiempo entre los primeros picos
    desfase_tiempo = tiempo_120hz[picos_3dma[0]] - tiempo_120hz[picos_xsens[0]]

    # Ajustar el tiempo del señal 3DMA
    tiempo_ajustado_3dma = tiempo_120hz - desfase_tiempo

    # Interpolación del señal 3DMA para que coincida con el tiempo de XSENS
    interp_func = interp1d(tiempo_ajustado_3dma, angulos_3dma, kind='linear', fill_value='extrapolate')
    angulos_3dma_alineados = interp_func(tiempo_120hz[:len(angulos_xsens)])

    return angulos_3dma_alineados, tiempo_120hz[:len(angulos_xsens)]

# =================== PROCESAMIENTO PRINCIPAL =================== #

def procesar_datos_torso(directorio, nombre_torso, usar_identidad=False):
    """
    Procesa datos del torso y retorna los ángulos:
    tilt (flex/ext), obliquity (abd/add), rotation (axial/int-ext).
    Retorna (N, 3).
    """
    torso_data = cargar_datos(directorio, nombre_torso)
    rot_torso = obtener_rotaciones(torso_data)
    R_SB_torso = calcular_R_SB(rot_torso, usar_identidad=usar_identidad)

    # --- Calcular los tres ángulos siempre ---
    torso_local = transformar_rotacion(rot_torso, R_SB_torso)
    angulos_torso = []
    for R_torso in torso_local:
        tilt = np.degrees(np.arctan2(R_torso[2, 0], R_torso[0, 0]))          # Tilt (flex/ext)
        obliquity = np.degrees(np.arctan2(R_torso[1, 0], R_torso[0, 0]))     # Obliquity (abd/add)
        #rotation = np.degrees(np.arctan2(R_torso[1, 2], R_torso[1, 1]))      # Rotation (axial)
        angulos_torso.append([tilt, obliquity])
    angulos_torso = np.array(angulos_torso)
    angulos_torso -= angulos_torso[0]  # Centra en 0 el frame inicial
    
    # --------- Restar bias (mediana) a cada columna ---------
    bias = np.median(angulos_torso, axis=0)  # (3,)
    angulos_torso -= bias
    
    
    return angulos_torso  # (N, 2)


def alinear_senales(angulos_xsens, angulos_3dma, tiempo_120hz):
    # Detectar picos usando el percentil 90 como umbral de altura
    picos_xsens, _ = find_peaks(angulos_xsens, height=np.percentile(angulos_xsens, 90))
    picos_3dma, _ = find_peaks(angulos_3dma, height=np.percentile(angulos_3dma, 90))

    # Validación de detección de picos
    if len(picos_xsens) == 0 or len(picos_3dma) == 0:
        print("⚠️ No se detectaron suficientes picos para alinear las señales.")
        return angulos_3dma, tiempo_120hz

    # Obtener el desfase de tiempo entre los primeros picos
    desfase_tiempo = tiempo_120hz[picos_3dma[0]] - tiempo_120hz[picos_xsens[0]]

    # Ajustar el tiempo del señal 3DMA
    tiempo_ajustado_3dma = tiempo_120hz - desfase_tiempo

    # Interpolación del señal 3DMA para que coincida con el tiempo de XSENS
    interp_func = interp1d(tiempo_ajustado_3dma, angulos_3dma, kind='linear', fill_value='extrapolate')
    angulos_3dma_alineados = interp_func(tiempo_120hz[:len(angulos_xsens)])

    return angulos_3dma_alineados, tiempo_120hz[:len(angulos_xsens)]


# Colors
rojo="#c83d34"
amarillo="#e7a347"

# Función para graficar comparación
def graficar_comparacion(tiempo, xsens_data, data_3dma, color_linea=rojo, color_ref=amarillo):
    plt.figure(figsize=(12, 5))
    plt.plot(tiempo[:4000], xsens_data[:4000], label='XSENS', color=color_linea)
    plt.plot(tiempo[:4000], data_3dma[:4000], label='3DMA (Interpolado)', color=color_ref)
    plt.title(f'Comparación ángulos torso XSENS VS 3DMA')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Ángulo (°)')
    plt.legend()
    plt.grid(True)
    plt.show()
    

# =================== EJECUCIÓN =================== #

# base_dir = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\Camila_Grazziani'
# ruta_xsens = os.path.join(base_dir, 'XSENS', 'XSENS CUATERNIONES', '3')
# ruta_3dma = os.path.join(base_dir, '3DMA', '3')

# # 1. Procesar datos de XSENS
# angulos_xsens = procesar_datos_torso(ruta_xsens, 'torso', usar_identidad=False)
# pelvis_3dma_data = cargar_datos_3dma(ruta_3dma, 'trunk angles.csv')

# columna_rot_3dma = 'Shoulders-Hips Rotation::Y'
# columna_t_3dma = 'Trunk Tilt::Y'
# columna_ob_3dma = 'Trunk Obliquity::Y'

# tiempo_3dma = np.linspace(0, len(pelvis_3dma_data) / 240, len(pelvis_3dma_data))
# interpolador = interp1d(tiempo_3dma, pelvis_3dma_data[columna_ob_3dma], fill_value='extrapolate')

# tiempo_120hz = np.linspace(0, len(angulos_xsens[:, 0]) / 120, len(angulos_xsens[:, 0]))
# pelvis_3dma_interpolado = interpolador(tiempo_120hz)

# pelvis_3dma_alineado, tiempo_ajustado = alinear_senales(angulos_xsens[:, 0], pelvis_3dma_interpolado, tiempo_120hz)
# pelvis_3dma_inicial = pelvis_3dma_alineado[0]
# pelvis_3dma_centrado =  pelvis_3dma_alineado - pelvis_3dma_inicial

# # Crear un array de tiempo para los ángulos de XSENS
# tiempo_xsens = np.linspace(0, len(angulos_xsens) / 120, len(angulos_xsens)) 

# # Graficar los ángulos del torso
# #graficar_angulos_torso(angulos_xsens, tiempo_xsens)
# graficar_comparacion(tiempo_120hz, angulos_xsens[:, 1], pelvis_3dma_centrado) 

