import pandas as pd
import numpy as np
import os

""" Este script hace extracción, recorte, normalización e integración de ciclos de marcha 
desde  XSENS y 3DMA, y guarda todo en dos Excel “maestros” por ángulo."""

# === CONFIGURACIÓN RUTAS ===
base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
todos_path = os.path.join(base_path, 'TODOS.xlsx')
base_3dma = os.path.join(base_path, 'RESULTADOS 3DMA')
NORM_POINTS = 100

ANGULOS = [
    # 'cadera_der_f_e', 'cadera_der_abd_add',
    # 'cadera_izq_f_e', 'cadera_izq_abd_add',
    # 'rodilla_der_f_e', 'rodilla_der_abd_add',
    # 'rodilla_izq_f_e', 'rodilla_izq_abd_add',
    'tobillo_der_f_e', 'tobillo_izq_f_e'
]

NOMBRES_3DMA = {
    # 'cadera_der_f_e': 'Right strides_F-E Hip.csv',
    # 'cadera_der_abd_add': 'Right strides_Ab-Ad Hip.csv',
    # 'cadera_izq_f_e': 'Left strides_F-E Hip.csv',
    # 'cadera_izq_abd_add': 'Left strides_Ab-Ad Hip.csv',
    # 'rodilla_der_f_e': 'Right strides_F-E Knee.csv',
    # 'rodilla_der_abd_add': 'Right strides_Ab-Ad Knee.csv',
    # 'rodilla_izq_f_e': 'Left strides_F-E Knee.csv',
    # 'rodilla_izq_abd_add': 'Right strides_Ab-Ad Knee.csv'
    'tobillo_der_f_e': 'Right strides_Ab-Ad Knee.csv'
}

def recortar_e_interpolar(df, columna, t_ini, t_fin, n_points=100):
    ciclo = df[(df['tiempo'] >= t_ini) & (df['tiempo'] <= t_fin)][columna].values
    if len(ciclo) < 2:
        return None
    x_old = np.linspace(0, 1, len(ciclo))
    x_new = np.linspace(0, 1, n_points)
    ciclo_interp = np.interp(x_new, x_old, ciclo)
    return ciclo_interp

# ========== CICLOS XSENS ==========
df_ciclos = pd.read_excel(todos_path)
ciclos_xsens = {ang: {} for ang in ANGULOS}

for idx, row in df_ciclos.iterrows():
    sujeto = row['SUJETO']
    captura = int(row['CAPTURA'])
    nombre_csv = f"{sujeto}_captura{captura}.csv"
    path_csv = os.path.join(base_path, sujeto, nombre_csv)
    if not os.path.isfile(path_csv):
        print(f"Archivo no encontrado: {path_csv}")
        continue
    df = pd.read_csv(path_csv)
    for lado in ['DERECHO', 'IZQUIERDO']:
        t_ini_col = f'{lado} INICIO'
        t_fin_col = f'{lado} FIN'
        t_ini = row[t_ini_col]
        t_fin = row[t_fin_col]
        t_ini_val = float(str(t_ini).replace(',', '.'))
        t_fin_val = float(str(t_fin).replace(',', '.'))
        if t_ini_val == 0.0 and t_fin_val == 0.0:
            continue
        if t_fin_val <= t_ini_val:
            continue
        if lado == 'DERECHO':
            angulos_lado = [
                'cadera_der_f_e', 'cadera_der_abd_add',
                'rodilla_der_f_e', 'rodilla_der_abd_add'
            ]
        else:
            angulos_lado = [
                'cadera_izq_f_e', 'cadera_izq_abd_add',
                'rodilla_izq_f_e', 'rodilla_izq_abd_add'
            ]
        for angulo in angulos_lado:
            ciclo_interp = recortar_e_interpolar(df, angulo, t_ini_val, t_fin_val, n_points=NORM_POINTS)
            if ciclo_interp is None:
                continue
            ciclo_name = f"{sujeto}_{captura}_{lado}"
            # Si hay más de un ciclo igual, añade un sufijo
            suffix = 1
            base_name = ciclo_name
            while ciclo_name in ciclos_xsens[angulo]:
                suffix += 1
                ciclo_name = f"{base_name}_{suffix}"
            ciclos_xsens[angulo][ciclo_name] = ciclo_interp

# Guarda cada ángulo en una hoja del Excel XSENS
xsens_path = os.path.join(base_path, "CICLOS_XSENS_TODOS.xlsx")
with pd.ExcelWriter(xsens_path) as writer:
    for angulo, ciclos in ciclos_xsens.items():
        if not ciclos:
            continue
        df_hoja = pd.DataFrame(ciclos)
        df_hoja.insert(0, "Ciclo de marcha (%)", np.linspace(0, 100, NORM_POINTS))
        df_hoja.to_excel(writer, sheet_name=angulo, index=False)
print(f"\n✅ CICLOS_XSENS_TODOS.xlsx guardado con todos los ciclos por hoja.")

# ========== CICLOS 3DMA ==========
ciclos_3dma = {ang: {} for ang in ANGULOS}
for sujeto in os.listdir(base_3dma):
    path_sujeto = os.path.join(base_3dma, sujeto)
    if not os.path.isdir(path_sujeto):
        continue
    for captura in os.listdir(path_sujeto):
        path_captura = os.path.join(path_sujeto, captura)
        if not os.path.isdir(path_captura):
            continue
        for angulo, nombre_archivo in NOMBRES_3DMA.items():
            path_ang = os.path.join(path_captura, nombre_archivo)
            if not os.path.isfile(path_ang):
                continue
            data = pd.read_csv(path_ang, header=0, dtype=float)
            for col in data.columns:
                ciclo = data[col].values
                if len(ciclo) != NORM_POINTS:
                    x_old = np.linspace(0, 1, len(ciclo))
                    x_new = np.linspace(0, 1, NORM_POINTS)
                    ciclo = np.interp(x_new, x_old, ciclo)
                ciclo_name = f"{sujeto}_{captura}_{col}"
                suffix = 1
                base_name = ciclo_name
                while ciclo_name in ciclos_3dma[angulo]:
                    suffix += 1
                    ciclo_name = f"{base_name}_{suffix}"
                ciclos_3dma[angulo][ciclo_name] = ciclo

dma_path = os.path.join(base_path, "CICLOS_3DMA_TODOS.xlsx")
with pd.ExcelWriter(dma_path) as writer:
    for angulo, ciclos in ciclos_3dma.items():
        if not ciclos:
            continue
        df_hoja = pd.DataFrame(ciclos)
        df_hoja.insert(0, "Ciclo de marcha (%)", np.linspace(0, 100, NORM_POINTS))
        df_hoja.to_excel(writer, sheet_name=angulo, index=False)
print(f"✅ CICLOS_3DMA_TODOS.xlsx guardado con todos los ciclos por hoja.")
