import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from scipy.spatial.distance import directed_hausdorff

try:
    from similaritymeasures import frechet_dist
    HAS_FRECHET = True
except ImportError:
    HAS_FRECHET = False
    print("⚠️ similaritymeasures no está instalado. Se usará Hausdorff como alternativa para Fréchet.")

""" Este código compara curvas angulares de marcha medidas con XSENS vs 3DMA para varios ángulos,
alinea las de 3DMA al patrón de XSENS, calcula métricas de similitud (RMSE, Pearson y Fréchet/Hausdorff), 
genera gráficas con bandas de desviación y guarda todas las figuras y una tabla de métricas en Excel."""


base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
file_xsens_copia = os.path.join(base_path, 'CICLOS_XSENS_COPIA.xlsx')
file_3dma_copia = os.path.join(base_path, 'CICLOS_3DMA_COPIA.xlsx')
imgs_path = os.path.join(base_path, "GRAFICAS_AURA")
os.makedirs(imgs_path, exist_ok=True)

ANGULOS = [
    'cadera_der_f_e', 'cadera_der_abd_add',
    'cadera_izq_f_e', 'cadera_izq_abd_add',
    'rodilla_der_f_e', 'rodilla_der_abd_add',
    'rodilla_izq_f_e', 'rodilla_izq_abd_add',
    'tobillo_der_f_e', 'tobillo_izq_f_e'
]
NORM_POINTS = 100

CRITERIO_ALINEACION = {
    'cadera_der_f_e': 'min',
    'cadera_der_abd_add': 'min',
    'cadera_izq_f_e': 'min',
    'cadera_izq_abd_add': 'min',
    'rodilla_der_f_e': 'max',
    'rodilla_der_abd_add': 'min',
    'rodilla_izq_f_e': 'max',
    'rodilla_izq_abd_add': 'min',
    'tobillo_der_f_e': 'min',
    'tobillo_izq_f_e': 'min'
}

def alinear_por_pico(x, y, tipo='max'):
    if tipo == 'max':
        idx_x = np.argmax(x)
        idx_y = np.argmax(y)
    else:
        idx_x = np.argmin(x)
        idx_y = np.argmin(y)
    shift = idx_x - idx_y
    return np.roll(y, shift)

resultados = []

for angulo in ANGULOS:
    df_xsens = pd.read_excel(file_xsens_copia, sheet_name=angulo)
    df_3dma  = pd.read_excel(file_3dma_copia, sheet_name=angulo)
    t = df_xsens['Ciclo de marcha (%)'] if 'Ciclo de marcha (%)' in df_xsens else np.linspace(0, 100, NORM_POINTS)

    ciclos_xsens = df_xsens.drop(columns=['Ciclo de marcha (%)'], errors='ignore').values
    ciclos_3dma = df_3dma.drop(columns=['Ciclo de marcha (%)'], errors='ignore').values

    # --- Alinear todos los ciclos de 3DMA a la media de XSENS (más robusto que a cada ciclo)
    x_mean = np.mean(ciclos_xsens, axis=1)
    ciclos_3dma_al = []
    criterio = CRITERIO_ALINEACION.get(angulo, 'max')
    for i in range(ciclos_3dma.shape[1]):
        y_al = alinear_por_pico(x_mean, ciclos_3dma[:, i], tipo=criterio)
        ciclos_3dma_al.append(y_al)
    ciclos_3dma_al = np.array(ciclos_3dma_al).T  # shape: NORM_POINTS x n_ciclos

    # Promedios y stds
    mean_xsens = x_mean
    std_xsens = np.std(ciclos_xsens, axis=1)
    mean_3dma = np.mean(ciclos_3dma_al, axis=1)
    std_3dma = np.std(ciclos_3dma_al, axis=1)

    # --- Métricas (Pearson, RMSE, Fréchet) entre promedios
    rmse = np.sqrt(np.mean((mean_xsens - mean_3dma) ** 2))
    try:
        pearson, _ = pearsonr(mean_xsens, mean_3dma)
    except Exception:
        pearson = np.nan
    xy1 = np.stack([t, mean_xsens]).T
    xy2 = np.stack([t, mean_3dma]).T
    if HAS_FRECHET:
        try:
            frechet = frechet_dist(xy1, xy2)
        except Exception:
            frechet = np.nan
    else:
        frechet = max(directed_hausdorff(xy1, xy2)[0], directed_hausdorff(xy2, xy1)[0])
    resultados.append({
        "angulo": angulo,
        "rmse": rmse,
        "pearson": pearson,
        "frechet": frechet
    })

    # --- GRAFICAR ---
    plt.figure(figsize=(8, 4))
    # XSENS (AURA) en azul
    plt.plot(t, mean_xsens, label="XSENS Aura (promedio)", lw=2, color='#2176ae')
    plt.fill_between(t, mean_xsens - std_xsens, mean_xsens + std_xsens, color='#c4d9ec', alpha=0.4)
    # 3DMA en negro
    plt.plot(t, mean_3dma, label="3DMA (promedio)", lw=2, color='black')
    plt.fill_between(t, mean_3dma - std_3dma, mean_3dma + std_3dma, color='#888888', alpha=0.3)
    plt.xlabel('Ciclo de marcha (%)')
    plt.ylabel('Ángulo (°)')
    plt.title(angulo.replace("_", " ").upper())
    # Métricas dentro del gráfico
    plt.text(
        0.01, 0.99,
        f"RMSE: {rmse:.2f}\nPearson: {pearson:.3f}\nFréchet: {frechet:.2f}",
        transform=plt.gca().transAxes,
        verticalalignment='top',
        horizontalalignment='left',
        fontsize=10,
        bbox=dict(facecolor='white', alpha=0.85, edgecolor="none")
    )
    plt.legend(fontsize=10, loc='lower right')
    plt.tight_layout()
    fname = f"AURA_vs_3DMA_{angulo}.png"
    plt.savefig(os.path.join(imgs_path, fname), dpi=200)
    plt.close()

print(f"✅ Imágenes guardadas en: {imgs_path}")

# Opcional: Guardar métricas a Excel
df_metrics = pd.DataFrame(resultados)
metrics_path = os.path.join(base_path, "METRICAS_INDIVIDUALES.xlsx")
df_metrics.to_excel(metrics_path, index=False)
