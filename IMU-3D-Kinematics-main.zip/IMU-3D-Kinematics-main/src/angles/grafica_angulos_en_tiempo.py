import pandas as pd
import matplotlib.pyplot as plt
import os

""" Lo que hace este codigo es con una sola captura.csv grafica los angulos en funcion del tiempo
    para todos los angulos que se quieren graficar. De forma simple, es mayormente para ver si hay errores
    en los angulos."""


# ----------- CONFIGURA AQUÍ -----------
# Cambiar la ruta
csv_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS\Daniela_Guerrero\Daniela_Guerrero_captura2.csv'


col_tiempo = 'tiempo'  # o None

# Lista de columnas de ángulos que quieres graficar
ANGULOS = [
    'cadera_der_f_e', 'cadera_der_abd_add',
    'cadera_izq_f_e', 'cadera_izq_abd_add',
    'rodilla_der_f_e', 'rodilla_der_abd_add',
    'rodilla_izq_f_e', 'rodilla_izq_abd_add',
    'tobillo_der_f_e', 'tobillo_izq_f_e'
]
# --------------------------------------


df = pd.read_csv(csv_path)

# Usa la columna de tiempo o el índice
if col_tiempo and col_tiempo in df.columns:
    t = df[col_tiempo].values
else:
    t = df.index.values

for ang in ANGULOS:
    if ang in df.columns:
        plt.figure(figsize=(12, 4))
        plt.plot(t, df[ang].values, color="#000000", lw=2)
        plt.xlabel('Tiempo' if col_tiempo else 'Índice de muestra')
        plt.ylabel('Ángulo (°)')
        plt.title(f'Serie temporal: {ang} con errores', fontsize=14)
        plt.tight_layout()
        plt.show()