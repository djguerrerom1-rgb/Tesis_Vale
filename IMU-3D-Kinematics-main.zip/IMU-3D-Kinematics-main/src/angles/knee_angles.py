import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation as R
from scipy.signal import find_peaks, butter, filtfilt, argrelextrema
from scipy.fftpack import fft, fftfreq
from sklearn.metrics import mean_squared_error
from scipy.ndimage import gaussian_filter1d
from scipy.stats import ttest_rel

#from src.utils.utils import (cargar_datos, cargar_datos_3dma, obtener_rotaciones, 
#                             calcular_R_SB, transformar_rotacion, alinear_senales)

# def calcular_angulos_rodilla(rot_muslo, rot_tibia, rot_pelvis, R_SB_muslo, R_SB_tibia, R_SB_pelvis):
#     """Calcula los ángulos de flexión/extensión, abducción/aducción y rotación interna/externa de la rodilla."""
#     angulos_rodilla = []
#     muslo_local = transformar_rotacion(rot_muslo, R_SB_muslo)
#     tibia_local = transformar_rotacion(rot_tibia, R_SB_tibia)
#     pelvis_local = transformar_rotacion(rot_pelvis, R_SB_pelvis)

#     for i in range(len(rot_muslo)):
#         R_muslo = rot_muslo[i]
#         R_tibia = rot_tibia[i]
#         R_pelvis = rot_pelvis[i]
#         R_rmuslo = pelvis_local[i].T @ muslo_local[i]
#         R_rtibia =  pelvis_local[i].T @ tibia_local[i]

#         # Ejes del muslo
#         x_muslo = R_rmuslo[:, 0]
#         y_muslo = R_rmuslo[:, 1]
#         z_muslo = R_rmuslo[:, 2]

#         # Ejes de la tibia
#         x_tibia = R_rtibia[:, 0]
#         y_tibia = R_rtibia[:, 1]
#         z_tibia = R_rtibia[:, 2]
        

#         # Ángulos de movimiento de la rodilla
        
#         flexion_extension = np.degrees(np.arccos(np.clip(np.dot(x_muslo, x_tibia) / (np.linalg.norm(x_muslo) * np.linalg.norm(x_tibia)), -1.0, 1.0)))
#         rotacion_interna_externa = np.degrees(np.arccos(np.clip(np.dot(y_muslo, z_tibia) / (np.linalg.norm(y_muslo) * np.linalg.norm(z_tibia)), -1.0, 1.0)))
#         varo_valgo = np.degrees(np.arctan2((R_rtibia[0, 0] - R_rtibia[1, 1]), R_rtibia[2, 2] + y_tibia[1]))
        

#         angulos_rodilla.append([flexion_extension, rotacion_interna_externa, varo_valgo])
    
#     angulos_rodilla = np.array(angulos_rodilla)
    
#     # Centrar los ángulos en 0
#     angulos_iniciales = angulos_rodilla[0]
#     angulos_centrados = angulos_rodilla - angulos_iniciales

#     return angulos_centrados



# =================== UTILIDADES DE ARCHIVOS Y CUATERNIONES ===================

def buscar_archivo(directorio, nombre_parcial):
    archivos = [f for f in os.listdir(directorio) if nombre_parcial in f]
    if not archivos:
        raise FileNotFoundError(f"No se encontró el archivo para {nombre_parcial}")
    return os.path.join(directorio, archivos[0])

def cargar_datos(directorio, nombre_sensor):
    path = buscar_archivo(directorio, nombre_sensor)
    return pd.read_csv(path)

def cargar_datos_3dma(directorio_3dma, nombre_archivo_3dma):
    path_3dma = buscar_archivo(directorio_3dma, nombre_archivo_3dma)
    return pd.read_csv(path_3dma, sep=';', decimal=',', encoding='utf-8')

def corregir_signo_cuaterniones(quats):
    quats_corr = [quats[0]]
    for i in range(1, len(quats)):
        if np.dot(quats_corr[-1], quats[i]) < 0:
            quats_corr.append(-quats[i])
        else:
            quats_corr.append(quats[i])
    return np.array(quats_corr)

def obtener_rotaciones(df):
    cuats = df[['Quat_W', 'Quat_X', 'Quat_Y', 'Quat_Z']].to_numpy()
    cuats_corr = corregir_signo_cuaterniones(cuats)
    rotaciones = R.from_quat(cuats_corr[:, [0, 1, 2, 3]])
    return rotaciones.as_matrix()

def calcular_R_SB(rotaciones, n=400, usar_identidad=False):
    if usar_identidad:
        return np.identity(3)
    rot_matrices = np.array(rotaciones[:n])
    U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
    R_SB = U @ Vt
    if np.linalg.det(R_SB) < 0:
        U[:, -1] *= -1
        R_SB = U @ Vt
    return R_SB

def transformar_rotacion(rotaciones, R_SB):
    return [R_SB.T @ rot for rot in rotaciones]

# =================== CÁLCULO DE ÁNGULOS DE RODILLA ===================

def flex_ext_rodilla(rot_muslo, rot_tibia, rot_pelvis, R_SB_muslo, R_SB_tibia, R_SB_pelvis):
    fe = []
    muslo_local = transformar_rotacion(rot_muslo, R_SB_muslo)
    tibia_local = transformar_rotacion(rot_tibia, R_SB_tibia)
    pelvis_local = transformar_rotacion(rot_pelvis, R_SB_pelvis)
    for i in range(len(muslo_local)):
        R_rmuslo = pelvis_local[i].T @ muslo_local[i]
        R_rtibia = pelvis_local[i].T @ tibia_local[i]
        x_muslo = R_rmuslo[:, 0]
        x_tibia = R_rtibia[:, 0]
        angle = np.degrees(np.arccos(np.clip(np.dot(x_muslo, x_tibia) /
                         (np.linalg.norm(x_muslo) * np.linalg.norm(x_tibia)), -1.0, 1.0)))
        fe.append(angle)
    return np.array(fe)

def rot_int_ext_rod(rot_muslo, rot_tibia, rot_pelvis, R_SB_muslo, R_SB_tibia, R_SB_pelvis):
    angulos = []
    muslo_local = transformar_rotacion(rot_muslo, R_SB_muslo)
    tibia_local = transformar_rotacion(rot_tibia, R_SB_tibia)
    pelvis_local = transformar_rotacion(rot_pelvis, R_SB_pelvis)
    for i in range(len(muslo_local)):
        R_rmuslo = pelvis_local[i].T @ muslo_local[i]
        R_rtibia = pelvis_local[i].T @ tibia_local[i]
        y_muslo = R_rmuslo[:, 1]
        z_tibia = R_rtibia[:, 2]
        angulo = np.degrees(np.arccos(np.clip(np.dot(y_muslo, z_tibia) /
                          (np.linalg.norm(y_muslo) * np.linalg.norm(z_tibia)), -1.0, 1.0)))
        angulos.append(angulo)
    rot = np.array(angulos)
    bias_rotacion = np.median(rot) # Puedes ajustar esto según tu caso
    rot -= bias_rotacion
    return rot

def varo_valgo_rod(rot_muslo, rot_tibia, rot_pelvis, R_SB_muslo, R_SB_tibia, R_SB_pelvis):
    angulos = []
    muslo_local = transformar_rotacion(rot_muslo, R_SB_muslo)
    tibia_local = transformar_rotacion(rot_tibia, R_SB_tibia)
    pelvis_local = transformar_rotacion(rot_pelvis, R_SB_pelvis)
    for i in range(len(tibia_local)):
        R_rtibia = pelvis_local[i].T @ tibia_local[i]
        y_tibia = R_rtibia[:, 1]
        angulo = np.degrees(np.arctan2((R_rtibia[0, 0] - R_rtibia[1, 1]),
                                       R_rtibia[2, 2] + y_tibia[1]))
        angulos.append(angulo)
    return np.array(angulos)

def procesar_datos_rodilla(directorio, nombre_muslo, nombre_tibia, nombre_pelvis, usar_identidad=False):
    muslo_data = cargar_datos(directorio, nombre_muslo)
    tibia_data = cargar_datos(directorio, nombre_tibia)
    pelvis_data = cargar_datos(directorio, nombre_pelvis)
    min_length = min(len(muslo_data), len(tibia_data), len(pelvis_data))
    muslo_data = muslo_data[:min_length]
    tibia_data = tibia_data[:min_length]
    pelvis_data = pelvis_data[:min_length]
    rot_muslo = obtener_rotaciones(muslo_data)
    rot_tibia = obtener_rotaciones(tibia_data)
    rot_pelvis = obtener_rotaciones(pelvis_data)
    R_SB_muslo = calcular_R_SB(rot_muslo, usar_identidad=usar_identidad)
    R_SB_tibia = calcular_R_SB(rot_tibia, usar_identidad=usar_identidad)
    R_SB_pelvis = calcular_R_SB(rot_pelvis, usar_identidad=usar_identidad)
    flex_ext = flex_ext_rodilla(rot_muslo, rot_tibia, rot_pelvis,R_SB_muslo, R_SB_tibia, R_SB_pelvis)
    rot_int_ext = rot_int_ext_rod(rot_muslo, rot_tibia, rot_pelvis,R_SB_muslo, R_SB_tibia, R_SB_pelvis)
    var_val = varo_valgo_rod(rot_muslo, rot_tibia, rot_pelvis,R_SB_muslo, R_SB_tibia, R_SB_pelvis)
    angulos_array = np.array([flex_ext, rot_int_ext, var_val]).T
    
    # --------- Restar bias (mediana) a cada columna ---------
    bias = np.median(angulos_array, axis=0)  # (3,)
    angulos_array-= bias
    
    return angulos_array

# =================== PREPROCESAMIENTO Y SUBPLOTS COMPARATIVOS ===================

def transformada_fourier(angulos, fs=120):
    fft_values = fft(angulos)
    fft_magnitude = np.abs(fft_values) / (len(angulos)/2)
    frequencies = fftfreq(len(angulos), d=1/fs)
    positive_freqs = frequencies[:len(frequencies)//2]
    positive_fft_magnitude = fft_magnitude[:len(frequencies)//2]
    return positive_freqs, positive_fft_magnitude

def alinear_senales(xsens, ref, tiempo_120hz):
    picos_xsens, _ = find_peaks(xsens, height=np.percentile(xsens, 90))
    picos_ref, _ = find_peaks(ref, height=np.percentile(ref, 90))
    if len(picos_xsens) == 0 or len(picos_ref) == 0:
        print("⚠️ No se detectaron suficientes picos para alinear las señales.")
        return ref, tiempo_120hz
    desfase_tiempo = tiempo_120hz[picos_ref[0]] - tiempo_120hz[picos_xsens[0]]
    tiempo_ajustado_ref = tiempo_120hz - desfase_tiempo
    interp_func = interp1d(tiempo_ajustado_ref, ref, kind='linear', fill_value='extrapolate')
    ref_alineada = interp_func(tiempo_120hz[:len(xsens)])
    return ref_alineada, tiempo_120hz[:len(xsens)]

def preprocesamiento_rodilla(xsens_ang, knee_3dma_col, tipo_extrema='min', nombre_plano=''):

    fs = 120
    t = np.arange(len(xsens_ang)) / fs

    # Interpolar y centrar 3DMA
    tiempo_3dma = np.linspace(0, len(knee_3dma_col) / fs, len(knee_3dma_col))
    interpolador = interp1d(tiempo_3dma, knee_3dma_col, fill_value='extrapolate')
    tiempo_120hz = np.linspace(0, len(xsens_ang) / fs, len(xsens_ang))
    knee_3dma_interpolado = interpolador(tiempo_120hz)
    knee_3dma_centrado = knee_3dma_interpolado - knee_3dma_interpolado[0]

    # Filtro pasabanda solo para segmentar
    lowcut, highcut = 0.5, 10
    order = 4
    nyq = 0.5 * fs
    b, a = butter(order, [lowcut / nyq, highcut / nyq], btype='band')
    xsens_filtrada = filtfilt(b, a, xsens_ang)

    # Segmentación en la señal filtrada (eventos)
    order_extrema = int(fs * 0.5)
    if tipo_extrema == 'max':
        eventos = argrelextrema(xsens_filtrada, np.greater, order=order_extrema)[0]
    else:
        eventos = argrelextrema(xsens_filtrada, np.less, order=order_extrema)[0]

    # Normalización de ciclos solo con la original (sin filtro)
    ciclos_xsens, ciclos_3dma = [], []
    for i in range(len(eventos)-1):
        ciclo_xsens = xsens_ang[eventos[i]:eventos[i+1]]
        ciclo_3dma = knee_3dma_centrado[eventos[i]:eventos[i+1]]
        if len(ciclo_xsens) < 10 or len(ciclo_3dma) < 10:
            continue
        ciclo_xsens_norm = np.interp(np.linspace(0, len(ciclo_xsens)-1, 100), np.arange(len(ciclo_xsens)), ciclo_xsens)
        ciclo_3dma_norm = np.interp(np.linspace(0, len(ciclo_3dma)-1, 100), np.arange(len(ciclo_3dma)), ciclo_3dma)
        ciclos_xsens.append(ciclo_xsens_norm)
        ciclos_3dma.append(ciclo_3dma_norm)
    ciclos_xsens = np.array(ciclos_xsens)
    ciclos_3dma = np.array(ciclos_3dma)
    media_xsens = np.mean(ciclos_xsens, axis=0) if len(ciclos_xsens) > 0 else None
    std_xsens = np.std(ciclos_xsens, axis=0) if len(ciclos_xsens) > 0 else None
    media_3dma = np.mean(ciclos_3dma, axis=0) if len(ciclos_3dma) > 0 else None
    std_3dma = np.std(ciclos_3dma, axis=0) if len(ciclos_3dma) > 0 else None

    # FFT (XSENS y 3DMA) solo para visualizar
    def transformada_fourier(signal, fs=120):
        fft_values = fft(signal)
        fft_magnitude = np.abs(fft_values) / (len(signal)/2)
        frequencies = fftfreq(len(signal), d=1/fs)
        positive_freqs = frequencies[:len(frequencies)//2]
        positive_fft_magnitude = fft_magnitude[:len(frequencies)//2]
        return positive_freqs, positive_fft_magnitude

    frec_xsens, fft_xsens = transformada_fourier(xsens_ang, fs=fs)
    frec_3dma, fft_3dma = transformada_fourier(knee_3dma_centrado, fs=fs)

    azul = '#3366cc'
    rojo = '#c83d34'

    plt.figure(figsize=(18,10))
    # 1. Señal original vs filtrada
    plt.subplot(2,2,1)
    plt.plot(t, xsens_ang, label='Original XSENS', color='black')
    plt.plot(t, knee_3dma_centrado, label='Original 3DMA', color='blue')
    plt.plot(t, xsens_filtrada, label='Filtrada (Butter)', color='green')
    plt.title(f'Señal original vs filtrada (Butterworth) {nombre_plano}')
    plt.xlabel('Tiempo [s]'); plt.ylabel('Ángulo [°]')
    plt.legend(); plt.grid(True)

    # 2. FFT ambas señales originales
    plt.subplot(2,2,2)
    plt.plot(frec_xsens, fft_xsens, label='FFT XSENS (120 Hz)')
    plt.plot(frec_3dma, fft_3dma, label='FFT 3DMA (120 Hz)', alpha=0.7)
    plt.xlabel('Frecuencia [Hz]')
    plt.ylabel('Amplitud')
    plt.title('FFT (Espectro señales originales)')
    plt.legend(); plt.xlim(0, 4); plt.ylim(0,10)
    plt.xticks(np.arange(0, 4.1, 0.2)); plt.grid(True)
    plt.yticks(np.arange(0, 10, 0.5)); plt.grid(True)

    # 3. Ciclos normalizados y promedios (solo la original)
    plt.subplot(2,2,3)
    for ciclo in ciclos_xsens:
        plt.plot(np.linspace(0,100,100), ciclo, color='gray', alpha=0.2)
    if media_xsens is not None:
        plt.plot(np.linspace(0,100,100), media_xsens, color=rojo, label='XSENS - Media ciclo', lw=2)
        plt.fill_between(np.linspace(0,100,100), media_xsens-std_xsens, media_xsens+std_xsens, color=rojo, alpha=0.2, label='XSENS ±1 STD')
    if media_3dma is not None:
        plt.plot(np.linspace(0,100,100), media_3dma, color=azul, label='3DMA - Media ciclo', lw=2)
        plt.fill_between(np.linspace(0,100,100), media_3dma-std_3dma, media_3dma+std_3dma, color=azul, alpha=0.2, label='3DMA ±1 STD')
    plt.title('Ciclos normalizados y ciclo promedio XSENS vs 3DMA')
    plt.xlabel('% ciclo de marcha'); plt.ylabel('Ángulo [°]')
    plt.legend(); plt.grid(True)

    # 4. Eventos sobre la señal filtrada
    plt.subplot(2,2,4)
    plt.plot(t, xsens_filtrada, label='Filtrada')
    plt.scatter(t[eventos], xsens_filtrada[eventos], color='r', label=f'{tipo_extrema.title()}s')
    plt.title('Segmentación por eventos')
    plt.xlabel('Tiempo [s]'); plt.ylabel('Ángulo [°]')
    plt.legend(); plt.grid(True)

    plt.tight_layout()
    plt.show()

    # RMSE entre promedios
    rmse = np.sqrt(mean_squared_error(media_xsens, media_3dma))
    print(f"RMSE entre ciclos promedio XSENS y 3DMA: {rmse:.2f} grados")

    return xsens_filtrada, eventos, media_xsens, std_xsens, media_3dma, std_3dma


#______________________GRAFICA SOLO RODILLA XSENS_______________________________#

# Colors
rojo="#c83d34"
amarillo="#e7a347"

def graficar_angulos_rodilla(flex, rot, var, tiempo):
    # """Grafica cada plano de movimiento por separado."""
    # plt.figure(figsize=(10, 4))
    # plt.plot(tiempo[0:4000], flex[0:4000], label='Flexión/Extensión', color='red')
    # plt.title('Flexión/Extensión de Rodilla (XSENS DOT)')
    # plt.xlabel('Tiempo (s)')
    # plt.ylabel('Ángulo (°)')
    # plt.grid(True)
    # plt.show()

    plt.figure(figsize=(10, 4))
    plt.plot(tiempo, rot, label='Rotación Interna/Externa', color='green')
    plt.title('Rotación Interna/Externa de Rodilla (XSENS DOT)')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Ángulo (°)')
    plt.grid(True)
    plt.show()

    # plt.figure(figsize=(10, 4))
    # plt.plot(tiempo, var, label='Varo/Valgo', color='blue')
    # plt.title('Varo/Valgo de Rodilla (XSENS DOT)')
    # plt.xlabel('Tiempo (s)')
    # plt.ylabel('Ángulo (°)')
    # plt.grid(True)
    # plt.show()

#_________________________PROCESAMIENTO RODILLA_______________________________#
def procesar_datos_rodilla(directorio, nombre_muslo, nombre_tibia, nombre_pelvis, usar_identidad=False):

    muslo_data = cargar_datos(directorio, nombre_muslo)
    tibia_data = cargar_datos(directorio, nombre_tibia)
    pelvis_data = cargar_datos(directorio, nombre_pelvis)

    # Asegurarse que los archivos tengan las columnas correctas y que estén alineados
    min_length = min(len(muslo_data), len(tibia_data), len(pelvis_data))
    muslo_data = muslo_data[:min_length]
    tibia_data = tibia_data[:min_length]
    pelvis_data = pelvis_data[:min_length]

    rot_muslo = obtener_rotaciones(muslo_data)
    rot_tibia = obtener_rotaciones(tibia_data)
    rot_pelvis = obtener_rotaciones(pelvis_data)

    # Matriz de rotación de referencia para la pelvis
    R_SB_muslo = calcular_R_SB(rot_muslo, usar_identidad=usar_identidad)
    R_SB_tibia = calcular_R_SB(rot_tibia, usar_identidad=usar_identidad)
    R_SB_pelvis = calcular_R_SB(rot_pelvis, usar_identidad=usar_identidad)

    flex_ext = flex_ext_rodilla(rot_muslo, rot_tibia, rot_pelvis,R_SB_muslo, R_SB_tibia, R_SB_pelvis)
    rot_int_ext = rot_int_ext_rod(rot_muslo, rot_tibia, rot_pelvis,R_SB_muslo, R_SB_tibia, R_SB_pelvis)
    var_val= varo_valgo_rod(rot_muslo, rot_tibia, rot_pelvis,R_SB_muslo, R_SB_tibia, R_SB_pelvis)

    # Devolver directamente un array NumPy, transponiendo para que las columnas sean los ángulos
    #kn= calcular_angulos_rodilla(rot_muslo,rot_tibia,rot_pelvis, R_SB_muslo, R_SB_tibia, R_SB_pelvis)
    angulos_array = np.array([flex_ext, rot_int_ext, var_val]).T
    return angulos_array

# Función para graficar comparación
def graficar_comparacion(tiempo, xsens_data, data_3dma, color_linea=rojo, color_ref=amarillo):
    plt.figure(figsize=(12, 5))
    plt.plot(tiempo[:4000], xsens_data[:4000], label='XSENS', color=color_linea)
    plt.plot(tiempo[:4000], data_3dma[:4000], label='3DMA (Interpolado)', color=color_ref)
    plt.title(f'Comparación Valgo / Varo XSENS vs 3DMA')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Ángulo (°)')
    plt.legend()
    plt.grid(True)
    plt.show()
    

# # # =================== EJECUCIÓN =================== #

#base_dir = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\Camila_Grazziani'
base_dir = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\Jose_Tavera'
ruta_xsens = os.path.join(base_dir, 'XSENS', 'XSENS_CUATERNIONES', '2')
ruta_3dma = os.path.join(base_dir, '3DMA', '2')

# 1. Procesar datos de XSENS
angulos_xsens = procesar_datos_rodilla(ruta_xsens, 'muslo_izq', 'tibia_izq', 'pelvis', usar_identidad=False)
knee_3dma_data = cargar_datos_3dma(ruta_3dma, 'knee angles.csv')
# Asegúrate de que estas columnas existan en tu archivo 3DMA
columna_fe_3dma = 'Right Knee Flexion/Extension::Y'
columna_ie_3dma = 'Left Knee Rotation::Y'
columna_vv_3dma = 'Right Knee Abduction/Adduction::Y'

tiempo_3dma = np.linspace(0, len(knee_3dma_data) / 240, len(knee_3dma_data))
interpolador = interp1d(tiempo_3dma, knee_3dma_data[columna_fe_3dma], fill_value='extrapolate')

tiempo_120hz = np.linspace(0, len(angulos_xsens[:, 0]) / 120, len(angulos_xsens[:, 2]))
knee_3dma_interpolado = interpolador(tiempo_120hz)

knee_3dma_alineado, tiempo_ajustado = alinear_senales(angulos_xsens[:, 0], knee_3dma_interpolado, tiempo_120hz)
knee_3dma_inicial = knee_3dma_alineado[0]
knee_3dma_centrado =  knee_3dma_alineado - knee_3dma_inicial

# Ejemplo: Comparar rotación interna/externa de rodilla
#senal_reconstruida, eventos, media_xsens, std_xsens, media_3dma, std_3dma = preprocesamiento_rodilla(angulos_xsens[:, 0], knee_3dma_centrado, tipo_extrema='min', nombre_plano="F/E rodilla")
graficar_angulos_rodilla(angulos_xsens[:, 0],angulos_xsens[:, 1],angulos_xsens[:, 2], tiempo_120hz)
graficar_comparacion(tiempo_120hz, angulos_xsens[:, 1], knee_3dma_centrado)

