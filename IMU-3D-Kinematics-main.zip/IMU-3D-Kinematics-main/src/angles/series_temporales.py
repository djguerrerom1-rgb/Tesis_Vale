import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from scipy.spatial.distance import directed_hausdorff
import matplotlib.cm as cm

base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
todos_path = os.path.join(base_path, 'TODOS.xlsx')
NORM_POINTS = 100

ANGULOS = [
    'cadera_der_f_e', 'cadera_der_abd_add',
    'cadera_izq_f_e', 'cadera_izq_abd_add',
    'rodilla_der_f_e', 'rodilla_der_abd_add',
    'rodilla_izq_f_e', 'rodilla_izq_abd_add',
    'tobillo_der_f_e', 'tobillo_izq_f_e'
]

def recortar_e_interpolar(df, columna, t_ini, t_fin, n_points=100):
    ciclo = df[(df['tiempo'] >= t_ini) & (df['tiempo'] <= t_fin)][columna].values
    if len(ciclo) < 2:
        return None
    x_old = np.linspace(0, 1, len(ciclo))
    x_new = np.linspace(0, 1, n_points)
    ciclo_interp = np.interp(x_new, x_old, ciclo)
    return ciclo_interp

# ========== CICLOS XSENS SOLO AURA ==========
df_ciclos = pd.read_excel(todos_path)
ciclos_xsens = {ang: {} for ang in ANGULOS}

for idx, row in df_ciclos.iterrows():
    sujeto = str(row['SUJETO'])
    if sujeto.strip().upper() != "AURA":
        continue
    captura = int(row['CAPTURA'])
    nombre_csv = f"{sujeto}_captura{captura}.csv"
    path_csv = os.path.join(base_path, sujeto, nombre_csv)
    if not os.path.isfile(path_csv):
        print(f"Archivo no encontrado: {path_csv}")
        continue
    df = pd.read_csv(path_csv)
    for lado in ['DERECHO', 'IZQUIERDO']:
        t_ini_col = f'{lado} INICIO'
        t_fin_col = f'{lado} FIN'
        t_ini = row[t_ini_col]
        t_fin = row[t_fin_col]
        t_ini_val = float(str(t_ini).replace(',', '.'))
        t_fin_val = float(str(t_fin).replace(',', '.'))
        if t_ini_val == 0.0 and t_fin_val == 0.0:
            continue
        if t_fin_val <= t_ini_val:
            continue
        if lado == 'DERECHO':
            angulos_lado = [
                'cadera_der_f_e', 'cadera_der_abd_add',
                'rodilla_der_f_e', 'rodilla_der_abd_add',
                'tobillo_der_f_e'
            ]
        else:
            angulos_lado = [
                'cadera_izq_f_e', 'cadera_izq_abd_add',
                'rodilla_izq_f_e', 'rodilla_izq_abd_add',
                'tobillo_izq_f_e'
            ]
        for angulo in angulos_lado:
            ciclo_interp = recortar_e_interpolar(df, angulo, t_ini_val, t_fin_val, n_points=NORM_POINTS)
            if ciclo_interp is None:
                continue
            ciclo_name = f"{sujeto}_{captura}_{lado}"
            # Si hay más de un ciclo igual, añade un sufijo
            suffix = 1
            base_name = ciclo_name
            while ciclo_name in ciclos_xsens[angulo]:
                suffix += 1
                ciclo_name = f"{base_name}_{suffix}"
            ciclos_xsens[angulo][ciclo_name] = ciclo_interp

# Guarda cada ángulo en una hoja del Excel XSENS (solo AURA)
xsens_path = os.path.join(base_path, "CICLOS_XSENS_AURA.xlsx")
with pd.ExcelWriter(xsens_path) as writer:
    for angulo, ciclos in ciclos_xsens.items():
        if not ciclos:
            continue
        df_hoja = pd.DataFrame(ciclos)
        df_hoja.insert(0, "Ciclo de marcha (%)", np.linspace(0, 100, NORM_POINTS))
        df_hoja.to_excel(writer, sheet_name=angulo, index=False)
print(f"\n✅ CICLOS_XSENS_AURA.xlsx guardado con todos los ciclos de AURA por hoja.")


base_3dma = os.path.join(base_path, 'RESULTADOS 3DMA')

NOMBRES_3DMA = {
    'cadera_der_f_e': 'Right strides_F-E Hip.csv',
    'cadera_der_abd_add': 'Right strides_Ab-Ad Hip.csv',
    'cadera_izq_f_e': 'Left strides_F-E Hip.csv',
    'cadera_izq_abd_add': 'Left strides_Ab-Ad Hip.csv',
    'rodilla_der_f_e': 'Right strides_F-E Knee.csv',
    'rodilla_der_abd_add': 'Right strides_Ab-Ad Knee.csv',
    'rodilla_izq_f_e': 'Left strides_F-E Knee.csv',
    'rodilla_izq_abd_add': 'Left strides_Ab-Ad Knee.csv',
    'tobillo_der_f_e': 'Right strides_F-E Ankle.csv',
    'tobillo_izq_f_e': 'Left strides_F-E Ankle.csv'
}

ciclos_3dma = {ang: {} for ang in ANGULOS}
sujeto = "AURA"
path_sujeto = os.path.join(base_3dma, sujeto)
if os.path.isdir(path_sujeto):
    for captura in os.listdir(path_sujeto):
        path_captura = os.path.join(path_sujeto, captura)
        if not os.path.isdir(path_captura):
            continue
        for angulo, nombre_archivo in NOMBRES_3DMA.items():
            path_ang = os.path.join(path_captura, nombre_archivo)
            if not os.path.isfile(path_ang):
                continue
            data = pd.read_csv(path_ang, header=0, dtype=float)
            for col in data.columns:
                ciclo = data[col].values
                if len(ciclo) != NORM_POINTS:
                    x_old = np.linspace(0, 1, len(ciclo))
                    x_new = np.linspace(0, 1, NORM_POINTS)
                    ciclo = np.interp(x_new, x_old, ciclo)
                ciclo_name = f"{sujeto}_{captura}_{col}"
                suffix = 1
                base_name = ciclo_name
                while ciclo_name in ciclos_3dma[angulo]:
                    suffix += 1
                    ciclo_name = f"{base_name}_{suffix}"
                ciclos_3dma[angulo][ciclo_name] = ciclo

dma_path = os.path.join(base_path, "CICLOS_3DMA_AURA.xlsx")
with pd.ExcelWriter(dma_path) as writer:
    for angulo, ciclos in ciclos_3dma.items():
        if not ciclos:
            continue
        df_hoja = pd.DataFrame(ciclos)
        df_hoja.insert(0, "Ciclo de marcha (%)", np.linspace(0, 100, NORM_POINTS))
        df_hoja.to_excel(writer, sheet_name=angulo, index=False)
print(f"✅ CICLOS_3DMA_AURA.xlsx guardado con todos los ciclos de AURA por hoja.")


# # === CONFIGURACIÓN RUTAS ===
# base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
# file_xsens_aura = os.path.join(base_path, 'CICLOS_XSENS_AURA.xlsx')
# file_3dma_aura = os.path.join(base_path, 'CICLOS_3DMA_AURA.xlsx')
# imgs_path = os.path.join(base_path, "GRAFICAS_AURA")
# os.makedirs(imgs_path, exist_ok=True)

# ANGULOS = [
#     'cadera_der_f_e', 'cadera_der_abd_add',
#     'cadera_izq_f_e', 'cadera_izq_abd_add',
#     'rodilla_der_f_e', 'rodilla_der_abd_add',
#     'rodilla_izq_f_e', 'rodilla_izq_abd_add',
#     'tobillo_der_f_e', 'tobillo_izq_f_e'
# ]
# NORM_POINTS = 100

# # --- Función para alinear y/o interpolar ciclos ---
# def interpolar_ciclo(y, n_points=NORM_POINTS):
#     x_old = np.linspace(0, 1, len(y))
#     x_new = np.linspace(0, 1, n_points)
#     return np.interp(x_new, x_old, y)


# resultados = []

# for angulo in ANGULOS:
#     try:
#         df_xsens = pd.read_excel(file_xsens_aura, sheet_name=angulo)
#         df_3dma  = pd.read_excel(file_3dma_aura,  sheet_name=angulo)
#     except Exception:
#         continue  # Si falta algún ángulo, lo ignora

#     ciclos_xsens = df_xsens.drop(columns=["Ciclo de marcha (%)"], errors='ignore')
#     ciclos_3dma  = df_3dma.drop(columns=["Ciclo de marcha (%)"], errors='ignore')
#     t = np.linspace(0, 100, NORM_POINTS)

#     # Crea carpeta para guardar por ángulo
#     img_dir = os.path.join(imgs_path, angulo)
#     os.makedirs(img_dir, exist_ok=True)

#     # Itera sobre todos los ciclos posibles de XSENS y 3DMA
#     for cx in ciclos_xsens.columns:
#         x = ciclos_xsens[cx].dropna().values
#         if len(x) < 2:
#             continue
#         x = interpolar_ciclo(x)  # Asegura misma longitud

#         for cy in ciclos_3dma.columns:
#             y = ciclos_3dma[cy].dropna().values
#             if len(y) < 2:
#                 continue
#             y = interpolar_ciclo(y)

#             # --- Métricas ---
#             if len(x) != len(y):
#                 continue
#             rmse = np.sqrt(np.mean((x - y) ** 2))
#             try:
#                 pearson, _ = pearsonr(x, y)
#             except Exception:
#                 pearson = np.nan
#             xy1 = np.stack([t, x]).T
#             xy2 = np.stack([t, y]).T
#             frechet = max(directed_hausdorff(xy1, xy2)[0], directed_hausdorff(xy2, xy1)[0])

#             resultados.append({
#                 "ciclo_xsens": cx,
#                 "ciclo_3dma": cy,
#                 "angulo": angulo,
#                 "rmse": rmse,
#                 "pearson": pearson,
#                 "frechet": frechet
#             })

#             # --- Graficar y guardar si Pearson > 0.7 ---
            
#                 plt.figure(figsize=(8, 4))
#                 line_xsens, = plt.plot(t, x, label="XSENS", lw=2, color='#d03c34')
#                 line_3dma,  = plt.plot(t, y, label="3DMA",  lw=2, color='#111111')
#                 plt.xlabel('Ciclo de marcha (%)', fontsize=12)
#                 plt.ylabel('Ángulo (°)', fontsize=12)
#                 plt.title(f"{cx} vs {cy}\n{angulo}", fontsize=13)
#                 plt.xticks(fontsize=10)
#                 plt.yticks(fontsize=10)
#                 plt.tight_layout()
#                 plt.grid(alpha=0.25)
#                 # Métricas en la gráfica (esquina superior izq)
#                 plt.text(
#                     0.01, 0.99,
#                     f"RMSE: {rmse:.2f}\nPearson: {pearson:.3f}\nFréchet: {frechet:.2f}",
#                     transform=plt.gca().transAxes,
#                     verticalalignment='top',
#                     horizontalalignment='left',
#                     fontsize=10,
#                     bbox=dict(facecolor='white', alpha=0.8, edgecolor="none")
#                 )
#                 # Solo promedios en la leyenda, abajo derecha, letra pequeña
#                 plt.legend(handles=[line_xsens, line_3dma], fontsize=9, loc='lower right')
#                 fname = f"{cx}_VS_{cy}_pearson_gt07.png".replace("/", "_")
#                 plt.savefig(os.path.join(img_dir, fname), dpi=200)
#                 plt.close()

# # --- Guardar las métricas en Excel ---
# df_metrics = pd.DataFrame(resultados)
# metrics_path = os.path.join(base_path, "METRICAS_INDIVIDUALES_AURA.xlsx")
# df_metrics.to_excel(metrics_path, index=False)
# print(f"\n✅ Métricas individuales de AURA guardadas en: {metrics_path}")
# print(f"✅ Gráficas guardadas por ángulo en: {imgs_path}")
