import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation as R
from scipy.signal import find_peaks, butter, lfilter, correlate, windows, fftconvolve, butter, filtfilt, argrelextrema
from scipy.fftpack import fft, fftfreq
from sklearn.metrics import mean_squared_error
from scipy.ndimage import gaussian_filter1d



"""Aqui están todas las funciones para calcular los angulos de tobillo a partir de los datos de XSENS
   y compararlos con los datos de 3DMA."""

# =================== FUNCIONES PRINCIPALES =================== #

def cargar_datos(directorio, nombre_tibia, nombre_pie):
    """Carga los archivos CSV de los sensores de tibia y pie."""
    tibia_path = buscar_archivo(directorio, nombre_tibia)
    pie_path = buscar_archivo(directorio, nombre_pie)
    return pd.read_csv(tibia_path), pd.read_csv(pie_path)

def buscar_archivo(directorio, nombre_parcial):
    """Busca un archivo en el directorio que contenga una palabra clave."""
    for archivo in os.listdir(directorio):
        if nombre_parcial in archivo and archivo.endswith('.csv'):
            return os.path.join(directorio, archivo)
    raise FileNotFoundError(f"No se encontró el archivo para {nombre_parcial}")

def ajustar_longitud(df1, df2):
    """Corta los DataFrames al mismo número de muestras."""
    min_length = min(len(df1), len(df2))
    return df1[:min_length], df2[:min_length]

# =================== PROCESAMIENTO DE CUATERNIONES =================== #
def cuaterniones_a_rotacion(qw, qx, qy, qz):
    q = np.array([qw, qx, qy, qz])
    r = R.from_quat(q)
    return r.as_matrix()

def obtener_rotaciones(df):
    return df.apply(lambda row: cuaterniones_a_rotacion(row['Quat_W'], row['Quat_X'], row['Quat_Y'], row['Quat_Z']), axis=1)


def calcular_R_SB(rotaciones, n=100, usar_identidad=False):
    if usar_identidad:
        return np.identity(3)
    
    rot_matrices = np.array(rotaciones[n:n+1])
    U, _, Vt = np.linalg.svd(np.mean(rot_matrices, axis=0))
    R = U @ Vt
    
    # Corrección si la matriz resultante es una reflexión (determinante -1)
    if np.linalg.det(R) < 0:
        U[:, -1] *= -1
        R = U @ Vt
    
    return R

# Se reconstruye la matriz de rotación válida en el espacio de Riemann
def transformar_rotacion(rotaciones, R_SB):
    return [R_SB.T @ rot for rot in rotaciones]


def calcular_angulo_tobillo(R_tibia, R_pie):
    """Calcula el ángulo de flexión/extensión del tobillo."""
    v_tibia = R_tibia @ np.array([1, 0, 0])
    v_pie = R_pie @ np.array([1, 0, 0])
    cos_theta = np.dot(v_tibia, v_pie) / (np.linalg.norm(v_tibia) * np.linalg.norm(v_pie))
    return np.degrees(np.arccos(np.clip(cos_theta, -1.0, 1.0)))


def calcular_angulos(rot_tibia, rot_pie):
    """Calcula los ángulos de flexión/extensión a lo largo del tiempo para tibia y pie."""
    angulos= [calcular_angulo_tobillo(Rt, Rp) for Rt, Rp in zip(rot_tibia, rot_pie)]
    # Ajustar el ángulo inicial a 0
    angulo_inicial = angulos[0]
    angulos_ajustados = [angulo - angulo_inicial for angulo in angulos]
    
    return angulos_ajustados

# =================== CARGAR DATOS 3DMA =================== #

def cargar_datos_3dma(directorio_3dma, nombre_archivo_3dma):
    """Carga los datos de 3DMA desde la ruta especificada."""
    path_3dma = buscar_archivo(directorio_3dma, nombre_archivo_3dma)
    return pd.read_csv(path_3dma, sep=';', decimal=',', encoding='utf-8')


# =================== GRAFICAR RESULTADOS =================== #
def alinear_senales(angulos_xsens, angulos_3dma, tiempo_120hz):
    picos_xsens, _ = find_peaks(angulos_xsens, height=np.percentile(angulos_xsens, 90))
    picos_3dma, _ = find_peaks(angulos_3dma, height=np.percentile(angulos_3dma, 90))

    if len(picos_xsens) == 0 or len(picos_3dma) == 0:
        print("No se detectaron suficientes picos para alinear las señales.")
        return angulos_3dma, tiempo_120hz
    
    desfase_tiempo = tiempo_120hz[picos_3dma[0]] - tiempo_120hz[picos_xsens[0]]
    tiempo_ajustado_3dma = tiempo_120hz - desfase_tiempo

    interp_func = interp1d(tiempo_ajustado_3dma, angulos_3dma, kind='linear', fill_value='extrapolate')
    angulos_3dma_alineados = interp_func(tiempo_120hz)
    
    return angulos_3dma_alineados, tiempo_ajustado_3dma

# Colors
rojo="#c83d34"
amarillo="#e7a347"
def graficar_comparacion(angulos_xsens, angulos_3dma, tiempo_120hz):
    plt.figure(figsize=(12, 6))
    plt.plot(tiempo_120hz[100:3000], angulos_xsens[100:3000], label='Xsens', color=rojo)
    plt.plot(tiempo_120hz[100:3000], angulos_3dma[100:3000], label='3DMA', color=amarillo)
    plt.title('Comparación de ángulo de flexión/extensión Tobillo')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Ángulo (°)')
    plt.yticks(range(-30, 40, 10))
    plt.legend()
    plt.grid(True)
    plt.show() 
# =================== PROCESAMIENTO COMPLETO =================== #

def preprocesamiento_tobillo(xsens_ang, ankle_3dma_col, tipo_extrema='min', nombre_plano=''):
    """
    Preprocesa y compara señal de tobillo de XSENS y 3DMA:
    - Segmenta ciclos usando la señal filtrada XSENS
    - Normaliza y promedia ciclos
    - Grafica señales, FFT y ciclos promedios

    Parámetros:
    xsens_ang: array, señal de ángulo XSENS
    ankle_3dma_col: array, señal de ángulo 3DMA ya interpolada, alineada y centrada
    tipo_extrema: 'min' o 'max' para segmentación de eventos
    nombre_plano: título opcional para las gráficas
    """
    fs = 120
    t = np.arange(len(xsens_ang)) / fs

    # Filtro pasabanda SOLO para segmentación
    lowcut, highcut = 1.4, 1.8
    order = 4
    nyq = 0.5 * fs
    b, a = butter(order, [lowcut / nyq, highcut / nyq], btype='band')
    xsens_filtrada = filtfilt(b, a, xsens_ang)

    # Segmentación en la señal filtrada (eventos)
    order_extrema = int(fs * 0.5)
    if tipo_extrema == 'max':
        eventos = argrelextrema(xsens_filtrada, np.greater, order=order_extrema)[0]
    else:
        eventos = argrelextrema(xsens_filtrada, np.less, order=order_extrema)[0]

    # Normalización de ciclos SOLO con la señal original (sin filtrar)
    ciclos_xsens, ciclos_3dma = [], []
    for i in range(len(eventos)-1):
        ciclo_xsens = xsens_ang[eventos[i]:eventos[i+1]]
        ciclo_3dma = ankle_3dma_col[eventos[i]:eventos[i+1]]
        if len(ciclo_xsens) < 10 or len(ciclo_3dma) < 10:
            continue
        ciclo_xsens_norm = np.interp(np.linspace(0, len(ciclo_xsens)-1, 100), np.arange(len(ciclo_xsens)), ciclo_xsens)
        ciclo_3dma_norm = np.interp(np.linspace(0, len(ciclo_3dma)-1, 100), np.arange(len(ciclo_3dma)), ciclo_3dma)
        ciclos_xsens.append(ciclo_xsens_norm)
        ciclos_3dma.append(ciclo_3dma_norm)
    ciclos_xsens = np.array(ciclos_xsens)
    ciclos_3dma = np.array(ciclos_3dma)
    media_xsens = np.mean(ciclos_xsens, axis=0) if len(ciclos_xsens) > 0 else None
    std_xsens = np.std(ciclos_xsens, axis=0) if len(ciclos_xsens) > 0 else None
    media_3dma = np.mean(ciclos_3dma, axis=0) if len(ciclos_3dma) > 0 else None
    std_3dma = np.std(ciclos_3dma, axis=0) if len(ciclos_3dma) > 0 else None

    # FFT (XSENS y 3DMA)
    def transformada_fourier(signal, fs=120):
        fft_values = fft(signal)
        fft_magnitude = np.abs(fft_values) / (len(signal)/2)
        frequencies = fftfreq(len(signal), d=1/fs)
        positive_freqs = frequencies[:len(frequencies)//2]
        positive_fft_magnitude = fft_magnitude[:len(frequencies)//2]
        return positive_freqs, positive_fft_magnitude

    frec_xsens, fft_xsens = transformada_fourier(xsens_ang, fs=fs)
    frec_3dma, fft_3dma = transformada_fourier(ankle_3dma_col, fs=fs)

    azul = '#3366cc'
    rojo = '#c83d34'

    plt.figure(figsize=(18,10))
    # 1. Señal original vs filtrada
    plt.subplot(2,2,1)
    plt.plot(t, xsens_ang, label='Original XSENS', color='black')
    #plt.plot(t, ankle_3dma_col, label='Original 3DMA', color='blue')
    plt.plot(t, xsens_filtrada, label='Filtrada (Butter)', color='green')
    plt.title(f'Señal original vs filtrada (Butterworth) {nombre_plano}')
    plt.xlabel('Tiempo [s]'); plt.ylabel('Ángulo [°]')
    plt.legend(); plt.grid(True)

    # 2. FFT ambas señales originales
    plt.subplot(2,2,2)
    plt.plot(frec_xsens, fft_xsens, label='FFT XSENS (120 Hz)')
    plt.plot(frec_3dma, fft_3dma, label='FFT 3DMA (120 Hz)', alpha=0.7)
    plt.xlabel('Frecuencia [Hz]')
    plt.ylabel('Amplitud')
    plt.title('FFT (Espectro señales originales)')
    plt.legend(); plt.xlim(0, 4); plt.ylim(0,10)
    plt.xticks(np.arange(0, 4.1, 0.2)); plt.grid(True)
    plt.yticks(np.arange(0, 10, 0.5)); plt.grid(True)

    # 3. Ciclos normalizados y promedios
    plt.subplot(2,2,3)
    for ciclo in ciclos_xsens:
        plt.plot(np.linspace(0,100,100), ciclo, color='gray', alpha=0.2)
    if media_xsens is not None:
        plt.plot(np.linspace(0,100,100), media_xsens, color=rojo, label='XSENS - Media ciclo', lw=2)
        plt.fill_between(np.linspace(0,100,100), media_xsens-std_xsens, media_xsens+std_xsens, color=rojo, alpha=0.2, label='XSENS ±1 STD')
    if media_3dma is not None:
        plt.plot(np.linspace(0,100,100), media_3dma, color=azul, label='3DMA - Media ciclo', lw=2)
        plt.fill_between(np.linspace(0,100,100), media_3dma-std_3dma, media_3dma+std_3dma, color=azul, alpha=0.2, label='3DMA ±1 STD')
    plt.title('Ciclos normalizados y ciclo promedio XSENS vs 3DMA')
    plt.xlabel('% ciclo de marcha'); plt.ylabel('Ángulo [°]')
    plt.legend(); plt.grid(True)

    # 4. Eventos sobre la señal filtrada
    plt.subplot(2,2,4)
    plt.plot(t, xsens_filtrada, label='Filtrada')
    plt.scatter(t[eventos], xsens_filtrada[eventos], color='r', label=f'{tipo_extrema.title()}s')
    plt.title('Segmentación por eventos')
    plt.xlabel('Tiempo [s]'); plt.ylabel('Ángulo [°]')
    plt.legend(); plt.grid(True)

    plt.tight_layout()
    plt.show()

    # RMSE entre promedios
    if media_xsens is not None and media_3dma is not None:
        rmse = np.sqrt(mean_squared_error(media_xsens, media_3dma))
        print(f"RMSE entre ciclos promedio XSENS y 3DMA: {rmse:.2f} grados")
    else:
        print("No se pudieron calcular los promedios.")

    return xsens_filtrada, eventos, media_xsens, std_xsens, media_3dma, std_3dma


def procesar_datos_tobillo(directorio, nombre_tibia, nombre_pie, usar_identidad=False):
    tibia_data, pie_data = cargar_datos(directorio, nombre_tibia, nombre_pie)

    min_length = min(len(tibia_data), len(pie_data))
    tibia_data = tibia_data[:min_length]
    pie_data = pie_data[:min_length]

    rot_tibia = obtener_rotaciones(tibia_data)
    rot_pie = obtener_rotaciones(pie_data)

    R_SB_tibia = calcular_R_SB(rot_tibia, usar_identidad=usar_identidad)
    R_SB_pie = calcular_R_SB(rot_pie, usar_identidad=usar_identidad)

    rot_tibia_global = transformar_rotacion(rot_tibia, R_SB_tibia)
    rot_pie_global = transformar_rotacion(rot_pie, R_SB_pie)

    # Calcula ángulo de dorsiflexión/plantarflexión (único ángulo para tobillo)
    angulos = [calcular_angulo_tobillo(Rt, Rp) for Rt, Rp in zip(rot_tibia_global, rot_pie_global)]
    angulos = np.array(angulos)
    angulos -= angulos[0] # Centrar en cero
    
    # --------- Restar bias (mediana) a cada columna ---------
    bias = np.median(angulos, axis=0)  # (3,)
    angulos -= bias
    
    return angulos

# =================== EJECUCIÓN =================== #


#base_dir = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\Camila_Grazziani'
base_dir = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\Jose_Tavera'
ruta_xsens = os.path.join(base_dir, 'XSENS', 'XSENS_CUATERNIONES', '2')
ruta_3dma = os.path.join(base_dir, '3DMA', '2')

# 1. Procesar datos de XSENS
angulos_xsens = procesar_datos_tobillo(ruta_xsens, 'tibia_der', 'pie_der', usar_identidad=False)
ankle_3dma_data = cargar_datos_3dma(ruta_3dma, 'ankle angles.csv')
# Asegúrate de que estas columnas existan en tu archivo 3DMA
columna_fe_3dma = 'Right Ankle Dorsal/Plantar Flexion::Y'

tiempo_3dma = np.linspace(0, len(ankle_3dma_data) / 240, len(ankle_3dma_data))
interpolador = interp1d(tiempo_3dma, ankle_3dma_data[columna_fe_3dma], fill_value='extrapolate')

tiempo_120hz = np.linspace(0, len(angulos_xsens) / 120, len(angulos_xsens))
knee_3dma_interpolado = interpolador(tiempo_120hz)

ankle_3dma_alineado, tiempo_ajustado = alinear_senales(angulos_xsens, knee_3dma_interpolado, tiempo_120hz)
ankle_3dma_inicial = ankle_3dma_alineado[0]
ankle_3dma_centrado =  ankle_3dma_alineado - ankle_3dma_inicial


#senal_reconstruida, eventos, media_xsens, std_xsens, media_3dma, std_3dma = preprocesamiento_tobillo(angulos_xsens, ankle_3dma_centrado, tipo_extrema='min', nombre_plano="F/E tobillo")
#graficar_angulos_rodilla(angulos_xsens[:, 0],angulos_xsens[:, 1],angulos_xsens[:, 2], tiempo_120hz)
graficar_comparacion(angulos_xsens,ankle_3dma_centrado, tiempo_120hz)


