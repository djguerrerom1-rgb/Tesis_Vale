"""

PLOT UNCALIBRTED AND CALIBRATED MAGNETOMETER MEASUREMENTS

Read data file with raw measurements and compare calibrated vs. uncalibrated
measurements.

Code By: Michael Wrona

The calibration equation is:
    h_calib = A * (h_meas - b)

h_calib: Calibrated measurements (3x1)
A: Soft iron, scale factor, and misalignment correction matrix (3x3, symmetric)
h_meas: Raw measurements (3x1)
b: Hard-iron offset correction vector (3x1)

Calibration parametrers were determined by the Magneto calibration software (see below).

Resources
---------


Magneto magnetometer calibration software download:
    https://sites.google.com/site/sailboatinstruments1/home

"""
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Define calibration parameters
A = np.array([[0.845609, 0.019281, 0.012070],
              [0.019281, 0.880514, -0.070764],
              [0.012070, -0.070764, 0.876461]])
b = np.array([40.395740, -8.366333, -27.975682])

# File paths
input_file = r"C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\TESIS 1\static_sensors\muslo_der_magnetometer_static_calibration_en_mT.txt"
output_file = r"C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\TESIS 1\static_sensors\muslo_der_magnetometer_static_calibration_en_uT.txt"

# Read raw data in mT and convert to µT
rawData_mT = np.genfromtxt(input_file, delimiter='\t')  # Read raw measurements
rawData_uT = rawData_mT * 1000  # Convert mT to µT

# Save the converted data to a new file
np.savetxt(output_file, rawData_uT, delimiter='\t', header="X [µT]\tY [µT]\tZ [µT]", comments='', fmt="%.6f")
print(f"Data converted to µT and saved to: {output_file}")

# Calibrate the data
N = len(rawData_uT)
calibData_uT = np.zeros((N, 3), dtype='float')
for i in range(N):
    currMeas = rawData_uT[i, :]
    calibData_uT[i, :] = A @ (currMeas - b)

# Plot XY data
plt.figure()
plt.plot(rawData_uT[:, 0], rawData_uT[:, 1], 'b*', label='Raw Meas.')
plt.plot(calibData_uT[:, 0], calibData_uT[:, 1], 'r*', label='Calibrated Meas.')
plt.title('XY Magnetometer Data')
plt.xlabel('X [µT]')
plt.ylabel('Y [µT]')
plt.legend()
plt.grid()
plt.axis('equal')

# Plot YZ data
plt.figure()
plt.plot(rawData_uT[:, 1], rawData_uT[:, 2], 'b*', label='Raw Meas.')
plt.plot(calibData_uT[:, 1], calibData_uT[:, 2], 'r*', label='Calibrated Meas.')
plt.title('YZ Magnetometer Data')
plt.xlabel('Y [µT]')
plt.ylabel('Z [µT]')
plt.legend()
plt.grid()
plt.axis('equal')

# Plot XZ data
plt.figure()
plt.plot(rawData_uT[:, 0], rawData_uT[:, 2], 'b*', label='Raw Meas.')
plt.plot(calibData_uT[:, 0], calibData_uT[:, 2], 'r*', label='Calibrated Meas.')
plt.title('XZ Magnetometer Data')
plt.xlabel('X [µT]')
plt.ylabel('Z [µT]')
plt.legend()
plt.grid()
plt.axis('equal')

# Colors
azul = "#006772"
amarillo = "#c07c04"

# Plot 3D scatter
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Scatter plot for raw and calibrated data
ax.scatter(rawData_uT[:, 0], rawData_uT[:, 1], rawData_uT[:, 2], color=azul, label='Sin calibrar')
ax.scatter(calibData_uT[:, 0], calibData_uT[:, 1], calibData_uT[:, 2], color=amarillo, label='Calibrados')


# Highlight the axes with bold black lines
margin = 0.1  # Add some extra space around the data
x_min, x_max = np.min(rawData_uT[:, 0]), np.max(rawData_uT[:, 0])
y_min, y_max = np.min(rawData_uT[:, 1]), np.max(rawData_uT[:, 1])
z_min, z_max = np.min(rawData_uT[:, 2]), np.max(rawData_uT[:, 2])

x_range = x_max - x_min
y_range = y_max - y_min
z_range = z_max - z_min

# Definir límites extendidos manualmente para que el gráfico se vea mejor
ax.set_xlim(-40, 80)  # Límites manuales ajustados
ax.set_ylim(-40, 40)
ax.set_zlim(-60, 20)

# Determinar un rango proporcional para las líneas de los ejes
axis_limit = max(abs(ax.get_xlim()[0]), abs(ax.get_xlim()[1]),
                 abs(ax.get_ylim()[0]), abs(ax.get_ylim()[1]),
                 abs(ax.get_zlim()[0]), abs(ax.get_zlim()[1]))

azul_osc="#1d3c5b"

# Graficar las líneas de los ejes sobre el origen
ax.plot([-axis_limit+20, axis_limit-20], [0, 0], [0, 0], color=azul_osc)
ax.plot([0, 0], [-axis_limit+20, axis_limit-20], [0, 0], color=azul_osc)
ax.plot([0, 0], [0, 0], [-axis_limit+20, axis_limit-20], color=azul_osc)
# Set titles and labels
ax.set_title('Diagrama de dispersión 3D de datos del magnetómetro')
ax.set_xlabel('X [µT]')
ax.set_ylabel('Y [µT]')
ax.set_zlabel('Z [µT]')

# Add legend for axes and data
handles, labels = ax.get_legend_handles_labels()
unique_labels = dict(zip(labels, handles))
ax.legend(unique_labels.values(), unique_labels.keys())


plt.show()