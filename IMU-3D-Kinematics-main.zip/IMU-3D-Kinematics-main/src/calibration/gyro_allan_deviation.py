import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os
from scipy.stats import linregress

# Ruta a la carpeta que contiene los archivos CSV
folder_path = r"C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\gyro allan"

# Archivo de salida donde se guardarán los promedios
output_file = r"C:\Users\Valentina\Documents\TESIS 1\calibracion muslo\mag sensor calibration.txt"

# Inicializa una lista para almacenar los resultados
results = []

# Config. params
file_name = 'gyro allan.csv'  # CSV data file "gx,gy,gz"
fs = 60  # Sample rate [Hz]

""" 
In order to understand the behaviour of the xsens dot through time, we developed an Allan Deviation
Analysis, the following function allows us to calculate the values
"""

# Función para calcular la pendiente en log-log
# Función para calcular la pendiente en log-log
def calculate_slope(tau, adev, tau_range):
    mask = (tau >= tau_range[0]) & (tau <= tau_range[1])
    if np.sum(mask) > 1:
        log_tau = np.log10(tau[mask])
        log_adev = np.log10(adev[mask])
        slope, intercept, _, _, _ = linregress(log_tau, log_adev)
        return slope, intercept
    return None, None

def AllanDeviation(dataArr: np.ndarray, fs: float, maxNumM: int=100):
    """Compute the Allan deviation (sigma) of time-series data.

    Algorithm obtained from Mathworks:
    https://www.mathworks.com/help/fusion/ug/inertial-sensor-noise-analysis-using-allan-variance.html

    Args
    ----

        dataArr: 1D data array
        fs: Data sample frequency in Hz
        maxNumM: Number of output points
    
    Returns
    -------
        (taus, allanDev): Tuple of results
        taus (numpy.ndarray): Array of tau values
        allanDev (numpy.ndarray): Array of computed Allan deviations
    """
    ts = 1.0 / fs
    N = len(dataArr)
    Mmax = 2**np.floor(np.log2(N / 2))
    M = np.logspace(np.log10(1), np.log10(Mmax), num=maxNumM)
    M = np.ceil(M)  # Round up to integer
    M = np.unique(M)  # Remove duplicates
    taus = M * ts  # Compute 'cluster durations' tau

    # Compute Allan variance
    allanVar = np.zeros(len(M))
    for i, mi in enumerate(M):
        twoMi = int(2 * mi)
        mi = int(mi)
        allanVar[i] = np.sum(
            (dataArr[twoMi:N] - (2.0 * dataArr[mi:N-mi]) + dataArr[0:N-twoMi])**2
        )
    
    allanVar /= (2.0 * taus**2) * (N - (2.0 * M))
    return (taus, np.sqrt(allanVar))  # Return deviation (dev = sqrt(var))



def compute_allan_deviation_plot(main_folder_path, sensor_folder, fs):
    """
    Calcula la desviación de Allan de los datos del giroscopio.
    
    Parámetros:
    - main_folder_path: Ruta principal que contiene las carpetas de los sensores.
    - sensor_folder: Nombre de la carpeta del sensor específico.
    - fs: Frecuencia de muestreo.
    """
    ts = 1.0 / fs
    
    # Ruta del archivo de calibración
    file_path = os.path.join(main_folder_path, f"{sensor_folder}_gyroscope_calibration.txt")
    
    # Lee el archivo de calibración sin encabezado, con tres columnas correspondientes a x, y, y z
    df = pd.read_csv(file_path, sep='\t', header=None)
    
    # Extrae las columnas por posición
    gyro_x = df.iloc[:, 0].dropna().values.flatten()
    gyro_y = df.iloc[:, 1].dropna().values.flatten()
    gyro_z = df.iloc[:, 2].dropna().values.flatten()

    # Calcula los ángulos del giroscopio
    thetax = np.cumsum(gyro_x) * ts  # [deg]
    thetay = np.cumsum(gyro_y) * ts
    thetaz = np.cumsum(gyro_z) * ts

    # Calcular las desviaciones de Allan
    (taux, adx) = AllanDeviation(thetax, fs, maxNumM=200)
    (tauy, ady) = AllanDeviation(thetay, fs, maxNumM=200)
    (tauz, adz) = AllanDeviation(thetaz, fs, maxNumM=200)
    
    # Definir el rango de interés para la pendiente
    tau_range = [1, 10]  # Modificar según el análisis deseado
    slope_x, _ = calculate_slope(taux, adx, tau_range)
    slope_y, _ = calculate_slope(tauy, ady, tau_range)
    slope_z, _ = calculate_slope(tauz, adz, tau_range)

    # Gráfico en escala log-log
    plt.figure()
    plt.title('Varianza de Allan Xsens Dot')
    plt.plot(taux, adx, label=f'gx (pend: {slope_x:.2f})', color=rojo)
    plt.plot(tauy, ady, label=f'gy (pend: {slope_y:.2f})', color=amarillo)
    plt.plot(tauz, adz, label=f'gz (pend: {slope_z:.2f})', color='black')
    
    
    plt.xlabel(r'$\tau$ [sec]')
    plt.ylabel('Deviation [deg/sec]')
    plt.grid(True, which="both", ls="-", color='0.65')
    plt.legend()
    plt.xscale('log')
    plt.yscale('log')
    plt.show()

# Colors
rojo="#c83d34"
amarillo="#e7a347"

# Ejemplo de uso de la función
main_folder_path = r"C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\gyro allan"
sensor_folder = "tibia"
compute_allan_deviation_plot(main_folder_path, sensor_folder, 60)

# =================== GRAFICAR RESULTADOS =================== #
