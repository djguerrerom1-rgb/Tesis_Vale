#Importamos librerías necesarias

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

"""
    
    Calibration_xsens.py: Este código corrige los 9 grados de libertad de los sensores xsens dot
    para emplearlos en un algortimo AHRS -Madgwick para permitir el calculo de cuaterniones en 
    orientaciones ajustadas.
    
"""

main_static_folder_path = r"C:\Users\Valentina\Documents\TESIS 1\static_sensors"
fs = 60  # Sample rate [Hz]

def acc_static_calibration(main_folder_path):
    """
    Calibra la aceleración de archivos estáticos CSV en subcarpetas y genera archivos de salida con
    promedios de aceleración en términos de g y m/s². g es necesario para obtener A y b con Magneto y m/s² para
    generar posteriormente el filtro de Madgwick.

    Parámetros:
    - main_folder_path: Ruta a la carpeta principal que contiene subcarpetas para cada sensor: static_sensors
    """
    # Recorre todas las subcarpetas en la carpeta principal
    for sensor_folder in os.listdir(main_folder_path):
        sensor_path = os.path.join(main_folder_path, sensor_folder)
        
        # Verifica que sea una carpeta
        if os.path.isdir(sensor_path):
            # Inicializa listas para almacenar los resultados en g y en m/s²
            sensor_results_g = []
            sensor_results_m_s2 = []

            # Recorre todos los archivos CSV en la subcarpeta
            for file_name in os.listdir(sensor_path):
                if file_name.endswith(".csv"):
                    file_path = os.path.join(sensor_path, file_name)
                    
                    # Lee el archivo CSV
                    df = pd.read_csv(file_path)
                    
                    # Calcula los promedios de Acc_X, Acc_Y, Acc_Z en g (divididos por 9.8)
                    avg_acc_x_g = df['Acc_X'].mean() / 9.8
                    avg_acc_y_g = df['Acc_Y'].mean() / 9.8
                    avg_acc_z_g = df['Acc_Z'].mean() / 9.8
                    
                    # Calcula los promedios de Acc_X, Acc_Y, Acc_Z en m/s² (sin normalización)
                    avg_acc_x_m_s2 = df['Acc_X'].mean()
                    avg_acc_y_m_s2 = df['Acc_Y'].mean()
                    avg_acc_z_m_s2 = df['Acc_Z'].mean()
                    
                    # Agrega los resultados a las listas correspondientes
                    sensor_results_g.append([avg_acc_x_g, avg_acc_y_g, avg_acc_z_g])
                    sensor_results_m_s2.append([avg_acc_x_m_s2, avg_acc_y_m_s2, avg_acc_z_m_s2])

            # Define las rutas de los archivos de salida específicos para este sensor
            output_file_g = os.path.join(main_folder_path, f"{sensor_folder}_acc_static_calibration_g.txt")
            output_file_m_s2 = os.path.join(main_folder_path, f"{sensor_folder}_acc_static_calibration_m_s2.txt")
            
            # Guarda los resultados en archivos .txt sin encabezados
            with open(output_file_g, 'w') as f_g, open(output_file_m_s2, 'w') as f_m_s2:
                for result in sensor_results_g:
                    f_g.write(f"{result[0]:.6f}\t{result[1]:.6f}\t{result[2]:.6f}\n")
                for result in sensor_results_m_s2:
                    f_m_s2.write(f"{result[0]:.6f}\t{result[1]:.6f}\t{result[2]:.6f}\n")

            print(f"Archivos de calibración guardados para {sensor_folder}:")
            print(f" - En g: {output_file_g}")
            print(f" - En m/s²: {output_file_m_s2}")

# Ejemplo de uso de la función
main_folder_path = r"C:\Users\Valentina\Documents\TESIS 1\static_sensors"
acc_static_calibration(main_folder_path)

#acc_static_calibration(main_static_folder_path)

##### AHORA PARA MAGNETOMETRO 

def mag_static_calibration(main_folder_path, campo_magnetico_terrestre_uT=30.0311):
    """
    Calibra el magnetómetro de archivos CSV en subcarpetas y genera archivos de salida con
    promedios de campo magnético en términos de µT, sin encabezado.

    Parámetros:
    - main_folder_path: Ruta a la carpeta principal que contiene subcarpetas para cada sensor.
    - campo_magnetico_terrestre_uT: Campo magnético terrestre conocido en µT para la conversión (por defecto es 30.0311 µT).
    """
    # Recorre todas las subcarpetas en la carpeta principal
    for sensor_folder in os.listdir(main_folder_path):
        sensor_path = os.path.join(main_folder_path, sensor_folder)
        
        # Verifica que sea una carpeta
        if os.path.isdir(sensor_path):
            # Inicializa listas para almacenar los resultados en µT
            all_mag_x_uT = []
            all_mag_y_uT = []
            all_mag_z_uT = []

            # Recorre todos los archivos CSV en la subcarpeta
            for file_name in os.listdir(sensor_path):
                if file_name.endswith(".csv"):
                    file_path = os.path.join(sensor_path, file_name)
                    
                    # Lee el archivo CSV
                    df = pd.read_csv(file_path)
                    
                    # Calcula los promedios de Mag_X, Mag_Y, Mag_Z en unidades arbitrarias
                    avg_mag_x = df['Mag_X'].mean()
                    avg_mag_y = df['Mag_Y'].mean()
                    avg_mag_z = df['Mag_Z'].mean()
                    
                    # Conversión a µT usando la normalización al campo magnético terrestre
                    avg_mag_x_uT = avg_mag_x * campo_magnetico_terrestre_uT
                    avg_mag_y_uT = avg_mag_y * campo_magnetico_terrestre_uT
                    avg_mag_z_uT = avg_mag_z * campo_magnetico_terrestre_uT
                    
                    # Agrega los resultados convertidos a las listas
                    all_mag_x_uT.append(avg_mag_x_uT)
                    all_mag_y_uT.append(avg_mag_y_uT)
                    all_mag_z_uT.append(avg_mag_z_uT)

            # Define la ruta del archivo de salida específico para este sensor
            output_file_uT = os.path.join(main_folder_path, f"{sensor_folder}_magnetometer_static_calibration.txt")
            
            # Guarda los resultados en un archivo .txt sin encabezado y en columnas
            with open(output_file_uT, 'w') as f:
                for x, y, z in zip(all_mag_x_uT, all_mag_y_uT, all_mag_z_uT):
                    f.write(f"{x}\t{y}\t{z}\n")

            print(f"Archivo de calibración de magnetómetro guardado para {sensor_folder} en: {output_file_uT}")

# Ejemplo de uso de la función
main_folder_path = r"C:\Users\Valentina\Documents\TESIS 1\static_sensors"
#mag_static_calibration(main_folder_path)


##### AHORA PARA GYROSCOPIO 

def AllanDeviation(dataArr: np.ndarray, fs: float, maxNumM: int=100):
    """Compute the Allan deviation (sigma) of time-series data.

    Algorithm obtained from Mathworks:
    https://www.mathworks.com/help/fusion/ug/inertial-sensor-noise-analysis-using-allan-variance.html

    Args
    ----

        dataArr: 1D data array
        fs: Data sample frequency in Hz
        maxNumM: Number of output points
    
    Returns
    -------
        (taus, allanDev): Tuple of results
        taus (numpy.ndarray): Array of tau values
        allanDev (numpy.ndarray): Array of computed Allan deviations
    """
    ts = 1.0 / fs
    N = len(dataArr)
    Mmax = 2**np.floor(np.log2(N / 2))
    M = np.logspace(np.log10(1), np.log10(Mmax), num=maxNumM)
    M = np.ceil(M)  # Round up to integer
    M = np.unique(M)  # Remove duplicates
    taus = M * ts  # Compute 'cluster durations' tau

    # Compute Allan variance
    allanVar = np.zeros(len(M))
    for i, mi in enumerate(M):
        twoMi = int(2 * mi)
        mi = int(mi)
        allanVar[i] = np.sum(
            (dataArr[twoMi:N] - (2.0 * dataArr[mi:N-mi]) + dataArr[0:N-twoMi])**2
        )
    
    allanVar /= (2.0 * taus**2) * (N - (2.0 * M))
    return (taus, np.sqrt(allanVar))  # Return deviation (dev = sqrt(var))


def gyr_calibration(main_folder_path):
    """
    Realiza la calibración de los datos del giroscopio, solo restando el sesgo, sirve para allan o datos mov.
    
    Parámetros:
    - main_folder_path: Ruta principal donde están las carpetas de los sensores.
    
    Retorna:
    - Ninguno.
    """
    threshold = 1
    # Recorre todas las subcarpetas en la carpeta principal
    for sensor_folder in os.listdir(main_folder_path):
        sensor_path = os.path.join(main_folder_path, sensor_folder)
        
        # Verifica que sea una carpeta
        if os.path.isdir(sensor_path):
            # Inicializa listas para almacenar los resultados
            all_gyr_x = []
            all_gyr_y = []
            all_gyr_z = []

            # Recorre todos los archivos CSV en la subcarpeta
            for file_name in os.listdir(sensor_path):
                if file_name.endswith(".csv"):
                    file_path = os.path.join(sensor_path, file_name)
                    
                    # Lee el archivo CSV
                    df = pd.read_csv(file_path)
                    # Convertir las columnas de giroscopio a numéricas y manejar errores
                    df['Gyr_X'] = pd.to_numeric(df['Gyr_X'], errors='coerce')
                    df['Gyr_Y'] = pd.to_numeric(df['Gyr_Y'], errors='coerce')
                    df['Gyr_Z'] = pd.to_numeric(df['Gyr_Z'], errors='coerce')

                    # Reemplazar valores anómalos con NaN
                    df['Gyr_X'] = df['Gyr_X'].apply(lambda x: np.nan if abs(x) > threshold else x)
                    df['Gyr_Y'] = df['Gyr_Y'].apply(lambda x: np.nan if abs(x) > threshold else x)
                    df['Gyr_Z'] = df['Gyr_Z'].apply(lambda x: np.nan if abs(x) > threshold else x)

                    # Eliminar filas con NaN para evitar errores en futuros cálculos
                    df.dropna(subset=['Gyr_X', 'Gyr_Y', 'Gyr_Z'], inplace=True)

                    # Calcular sesgo (bias) de los datos filtrados
                    gyro_x_bias = np.mean(df['Gyr_X'])
                    gyro_y_bias = np.mean(df['Gyr_Y'])
                    gyro_z_bias = np.mean(df['Gyr_Z']) 

                    # Corregir lecturas
                    gyro_x = df['Gyr_X'].values - gyro_x_bias
                    gyro_y = df['Gyr_Y'].values - gyro_y_bias
                    gyro_z = df['Gyr_Z'].values - gyro_z_bias 

                    # Agregar resultados a las listas
                    all_gyr_x.extend(gyro_x)
                    all_gyr_y.extend(gyro_y)
                    all_gyr_z.extend(gyro_z)

            # Guarda los resultados en un archivo .txt sin encabezado, con tres columnas
            output_file_gyr = os.path.join(main_folder_path, f"{sensor_folder}_gyroscope_calibration.txt")
            with open(output_file_gyr, 'w') as f:
                for x, y, z in zip(all_gyr_x, all_gyr_y, all_gyr_z):
                    f.write(f"{x}\t{y}\t{z}\n")

            print(f"Archivo de calibración de giroscopio guardado para {sensor_folder} en: {output_file_gyr}")

# Ejemplo de uso de la función
#main_folder_path = r"C:\Users\Valentina\Documents\TESIS 1\static_sensors"
#gyr_static_calibration(main_folder_path)

def compute_allan_deviation_plot(main_folder_path, sensor_folder, fs):
    """
    Calcula la desviación de Allan de los datos del giroscopio.
    
    Parámetros:
    - main_folder_path: Ruta principal que contiene las carpetas de los sensores.
    - sensor_folder: Nombre de la carpeta del sensor específico.
    - fs: Frecuencia de muestreo.
    """
    ts = 1.0 / fs
    
    # Ruta del archivo de calibración
    file_path = os.path.join(main_folder_path, f"{sensor_folder}_gyroscope_calibration.txt")
    
    # Lee el archivo de calibración sin encabezado, con tres columnas correspondientes a x, y, y z
    df = pd.read_csv(file_path, sep='\t', header=None)
    
    # Extrae las columnas por posición
    gyro_x = df.iloc[:, 0].dropna().values.flatten()
    gyro_y = df.iloc[:, 1].dropna().values.flatten()
    gyro_z = df.iloc[:, 2].dropna().values.flatten()

    # Calcula los ángulos del giroscopio
    thetax = np.cumsum(gyro_x) * ts  # [deg]
    thetay = np.cumsum(gyro_y) * ts
    thetaz = np.cumsum(gyro_z) * ts

    # Calcular las desviaciones de Allan
    (taux, adx) = AllanDeviation(thetax, fs, maxNumM=200)
    (tauy, ady) = AllanDeviation(thetay, fs, maxNumM=200)
    (tauz, adz) = AllanDeviation(thetaz, fs, maxNumM=200)

    # Gráfico en escala logarítmica
    plt.figure()
    plt.title('Gyro Allan Deviations')
    plt.plot(taux, adx, label='gx')
    plt.plot(tauy, ady, label='gy')
    plt.plot(tauz, adz, label='gz')
    plt.xlabel(r'$\tau$ [sec]')
    plt.ylabel('Deviation [deg/sec]')
    plt.grid(True, which="both", ls="-", color='0.65')
    plt.legend()
    plt.xscale('log')
    plt.yscale('log')
    plt.show()

# Ejemplo de uso
main_folder_path = r"C:\Users\Valentina\Documents\TESIS 1\gyro allan"
sensor_folder = "tibia"
fs = 60  # Frecuencia de muestreo

compute_allan_deviation_plot(main_folder_path, sensor_folder, fs)


## AHORA VAMOS A COMPUTAR OTROS ANALISIS DE RUIDO QUE PUEDEN SER PERTINENTES EN UNA SOLA FUNCION

