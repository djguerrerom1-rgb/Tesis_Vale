import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def perform_acc_calibration(sensor_name, data_file, calibration_file):
    # Leer parámetros de calibración desde la hoja específica
    print("hola")
    calib_params = pd.read_excel(calibration_file, sheet_name="acc")
    
    sensor_params = calib_params[calib_params['SENSOR'] == sensor_name]

    if sensor_params.empty:
        raise ValueError(f"Sensor '{sensor_name}' no encontrado en la hoja '{"acc"}' del archivo de calibración.")

    # Extraer la matriz A y el vector b
    A = sensor_params.iloc[0, 1:10].values.reshape(3, 3).astype(float)
    b = sensor_params.iloc[0, 10:13].values.astype(float)

    # Leer datos sin procesar desde el archivo txt
    raw_data = np.genfromtxt(data_file, delimiter='\t')

    # Aplicar la calibración
    calib_data = np.array([A @ (raw - b) for raw in raw_data[:, :3]])

    return raw_data, calib_data


def plot_accelerometer_data(raw_data, calib_data, units='m/s^2'):
    # Graficar datos XY
    plt.figure()
    plt.plot(raw_data[:, 0], raw_data[:, 1], 'b*', label='Sin calibrar')
    plt.plot(calib_data[:, 0], calib_data[:, 1], 'r*', label='Calibrados')
    plt.title('Datos XY del Acelerómetro')
    plt.xlabel(f'X [{units}]')
    plt.ylabel(f'Y [{units}]')
    plt.legend()
    plt.grid()
    plt.axis('equal')

    # Graficar datos YZ
    plt.figure()
    plt.plot(raw_data[:, 1], raw_data[:, 2], 'b*', label='Sin calibrar')
    plt.plot(calib_data[:, 1], calib_data[:, 2], 'r*', label='Calibrados')
    plt.title('Datos YZ del Acelerómetro')
    plt.xlabel(f'Y [{units}]')
    plt.ylabel(f'Z [{units}]')
    plt.legend()
    plt.grid()
    plt.axis('equal')

    # Graficar datos XZ
    plt.figure()
    plt.plot(raw_data[:, 0], raw_data[:, 2], 'b*', label='Sin calibrar')
    plt.plot(calib_data[:, 0], calib_data[:, 2], 'r*', label='Calibrados')
    plt.title('Datos XZ del Acelerómetro')
    plt.xlabel(f'X [{units}]')
    plt.ylabel(f'Z [{units}]')
    plt.legend()
    plt.grid()
    plt.axis('equal')

    # Graficar diagrama de dispersión 3D
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(raw_data[:, 0], raw_data[:, 1], raw_data[:, 2], color='#006772', label='Sin calibrar')
    ax.scatter(calib_data[:, 0], calib_data[:, 1], calib_data[:, 2], color='#c07c04', label='Calibrados')

    ax.set_title('Diagrama de Dispersión 3D de Datos del Acelerómetro')
    ax.set_xlabel(f'X [{units}]')
    ax.set_ylabel(f'Y [{units}]')
    ax.set_zlabel(f'Z [{units}]')
    ax.legend()

    plt.show()


# Definir los archivos de entrada
sensor_name = 'muslo_der'  # Nombre del sensor según aparece en la hoja "X"
data_file = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\static_sensors\muslo_der_acc_static_calibration_m_s2.txt' # Ruta al archivo de datos crudos (.txt)
calibration_file = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\src\calibration\magneto_calibration_results.xlsx'  # Ruta al archivo de calibración (.xlsx)

# Paso 1: Calibrar los datos
raw_data, calib_data = perform_acc_calibration(sensor_name, data_file, calibration_file)

# Paso 2: Graficar los datos sin calibrar y calibrados
plot_accelerometer_data(raw_data, calib_data, units='m/s^2')