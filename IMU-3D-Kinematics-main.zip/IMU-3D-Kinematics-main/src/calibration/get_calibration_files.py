import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.fft import fft, fftfreq
from scipy.stats import shapiro

"""
    
    calibration.py: This code aims to calculate the calibration of 10 different xsens dot sensors.
    It starts by calculating static calibration data, placed on a .txt that after goes to Magneto 
    to get the calibration matrix and vector used to calibrate ACC and Mag data. For the gyroscope 
    calibration, we use a simple numerical adjustment of the data without filtering. The aim of the 
    calibration is to obtain the 9DOF improved to calculate Madgwick Filter and get cuaternions to do
    the operations.
    
"""

def acc_static_calibration_files(main_folder_path):
    """
    Calibrates the acceleration of static CSV files in subfolders and generates output files 
    with acceleration averages in terms of g and m/s². g is needed to obtain A and b with 
    Magneto and m/s² to subsequently generate the Madgwick filter.

    Parámetros:
    - main_folder_path: Path to the main folder containing subfolders for each sensor: static_sensors
    """
    # Recorre todas las subcarpetas en la carpeta principal
    for sensor_folder in os.listdir(main_folder_path):
        sensor_path = os.path.join(main_folder_path, sensor_folder)
        
        # Verifica que sea una carpeta
        if os.path.isdir(sensor_path):
            # Inicializa listas para almacenar los resultados en g y en m/s²
            sensor_results_g = []
            sensor_results_m_s2 = []

            # Recorre todos los archivos CSV en la subcarpeta
            for file_name in os.listdir(sensor_path):
                if file_name.endswith(".csv"):
                    file_path = os.path.join(sensor_path, file_name)
                    
                    # Lee el archivo CSV
                    df = pd.read_csv(file_path)
                    
                    # Calcula los promedios de Acc_X, Acc_Y, Acc_Z en g (divididos por 9.8)
                    avg_acc_x_g = df['Acc_X'].mean() / 9.8
                    avg_acc_y_g = df['Acc_Y'].mean() / 9.8
                    avg_acc_z_g = df['Acc_Z'].mean() / 9.8
                    
                    # Calcula los promedios de Acc_X, Acc_Y, Acc_Z en m/s² (sin normalización)
                    avg_acc_x_m_s2 = df['Acc_X'].mean()
                    avg_acc_y_m_s2 = df['Acc_Y'].mean()
                    avg_acc_z_m_s2 = df['Acc_Z'].mean()
                    
                    # Agrega los resultados a las listas correspondientes
                    sensor_results_g.append([avg_acc_x_g, avg_acc_y_g, avg_acc_z_g])
                    sensor_results_m_s2.append([avg_acc_x_m_s2, avg_acc_y_m_s2, avg_acc_z_m_s2])

            # Define las rutas de los archivos de salida específicos para este sensor
            output_file_g = os.path.join(main_folder_path, f"{sensor_folder}_acc_static_calibration_g.txt")
            output_file_m_s2 = os.path.join(main_folder_path, f"{sensor_folder}_acc_static_calibration_m_s2.txt")
            
            # Guarda los resultados en archivos .txt sin encabezados
            with open(output_file_g, 'w') as f_g, open(output_file_m_s2, 'w') as f_m_s2:
                for result in sensor_results_g:
                    f_g.write(f"{result[0]:.6f}\t{result[1]:.6f}\t{result[2]:.6f}\n")
                for result in sensor_results_m_s2:
                    f_m_s2.write(f"{result[0]:.6f}\t{result[1]:.6f}\t{result[2]:.6f}\n")

            print(f"Archivos de calibración guardados para {sensor_folder}:")
            print(f" - En g: {output_file_g}")
            print(f" - En m/s²: {output_file_m_s2}")


""" The files obtained in the previous calibration go to Magneto 1.2 in which it is necessary 
to place the magnetic field according to the unit of the results, in our case, we place the 
magnetic field in 9.8m/s2 and record the results on a CSV called magneto_calibration_results.csv"
"""

def mag_static_calibration_files(main_folder_path, campo_magnetico_uT=30.0311):
    """
    Calibrate magnetometer from CSV files in subfolders and save the averages of
    Mag_X, Mag_Y, Mag_Z in mT in tabulated output files without header.

    Parameters:
    - main_folder_path: Path of the main folder containing subfolders for each sensor.
    - magnetic_field_uT: Value of the known Earth magnetic field in µT (default 30.0311 µT).
    """
    for sensor_folder in os.listdir(main_folder_path):
        sensor_path = os.path.join(main_folder_path, sensor_folder)

        if os.path.isdir(sensor_path):
            resultados = []  # Almacena los resultados de todos los archivos CSV

            for file in os.listdir(sensor_path):
                if file.endswith(".csv"):
                    df = pd.read_csv(os.path.join(sensor_path, file))
                    # Calcula el promedio de Mag_X, Mag_Y, Mag_Z y convierte a µT
                    prom_uT = df[['Mag_X', 'Mag_Y', 'Mag_Z']].mean() * campo_magnetico_uT / 1000
                    resultados.append(prom_uT.values)

            # Guarda los resultados en un archivo tabulado sin encabezado
            output_file = os.path.join(main_folder_path, f"{sensor_folder}_magnetometer_calibration_mT.txt")
            pd.DataFrame(resultados, columns=['Mag_X_mT', 'Mag_Y_mT', 'Mag_Z_mT']).to_csv(output_file, sep='\t', index=False, header=False)

            print(f"Calibración guardada para {sensor_folder} en: {output_file}")


    """
    Finally, we perform the calibration of the gyroscope numerically with the following fuction
    only subtracting bias and generating a txt, useful for allan or motion data.
    """

def gyr_static_calibration_files(main_folder_path):
    """
    Performs calibration of the gyroscope data, only subtracting the bias, it is used for allan or motion data.

    Parameters:
    - main_folder_path: Main path where the sensor folders are.

    Returns:
    - None.
    """
    threshold = 1
    # Recorre todas las subcarpetas en la carpeta principal
    for sensor_folder in os.listdir(main_folder_path):
        sensor_path = os.path.join(main_folder_path, sensor_folder)
        
        # Verifica que sea una carpeta
        if os.path.isdir(sensor_path):
            # Inicializa listas para almacenar los resultados
            all_gyr_x = []
            all_gyr_y = []
            all_gyr_z = []

            # Recorre todos los archivos CSV en la subcarpeta
            for file_name in os.listdir(sensor_path):
                if file_name.endswith(".csv"):
                    file_path = os.path.join(sensor_path, file_name)
                    
                    # Lee el archivo CSV
                    df = pd.read_csv(file_path)
                    # Convertir las columnas de giroscopio a numéricas y manejar errores
                    df['Gyr_X'] = pd.to_numeric(df['Gyr_X'], errors='coerce')
                    df['Gyr_Y'] = pd.to_numeric(df['Gyr_Y'], errors='coerce')
                    df['Gyr_Z'] = pd.to_numeric(df['Gyr_Z'], errors='coerce')

                    # Reemplazar valores anómalos con NaN
                    df['Gyr_X'] = df['Gyr_X'].apply(lambda x: np.nan if abs(x) > threshold else x)
                    df['Gyr_Y'] = df['Gyr_Y'].apply(lambda x: np.nan if abs(x) > threshold else x)
                    df['Gyr_Z'] = df['Gyr_Z'].apply(lambda x: np.nan if abs(x) > threshold else x)

                    # Eliminar filas con NaN para evitar errores en futuros cálculos
                    df.dropna(subset=['Gyr_X', 'Gyr_Y', 'Gyr_Z'], inplace=True)

                    # Calcular sesgo (bias) de los datos filtrados
                    gyro_x_bias = np.mean(df['Gyr_X'])
                    gyro_y_bias = np.mean(df['Gyr_Y'])
                    gyro_z_bias = np.mean(df['Gyr_Z']) 

                    # Corregir lecturas
                    gyro_x = df['Gyr_X'].values - gyro_x_bias
                    gyro_y = df['Gyr_Y'].values - gyro_y_bias
                    gyro_z = df['Gyr_Z'].values - gyro_z_bias 

                    # Agregar resultados a las listas
                    all_gyr_x.extend(gyro_x)
                    all_gyr_y.extend(gyro_y)
                    all_gyr_z.extend(gyro_z)

            # Guarda los resultados en un archivo .txt sin encabezado, con tres columnas
            output_file_gyr = os.path.join(main_folder_path, f"{sensor_folder}_gyroscope_calibration.txt")
            with open(output_file_gyr, 'w') as f:
                for x, y, z in zip(all_gyr_x, all_gyr_y, all_gyr_z):
                    f.write(f"{x}\t{y}\t{z}\n")

            print(f"Archivo de calibración de giroscopio guardado para {sensor_folder} en: {output_file_gyr}")