import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os

# Ruta a la carpeta que contiene los archivos CSV
folder_path = r"C:\Users\Valentina\Documents\TESIS 1\gyro allan"

# Archivo de salida donde se guardarán los promedios
output_file = r"C:\Users\Valentina\Documents\TESIS 1\calibracion muslo\mag sensor calibration.txt"

# Inicializa una lista para almacenar los resultados
results = []

# Config. params
file_name = 'gyro allan.csv'  # CSV data file "gx,gy,gz"
fs = 60  # Sample rate [Hz]

def AllanDeviation(dataArr: np.ndarray, fs: float, maxNumM: int=100):
    """Compute the Allan deviation (sigma) of time-series data."""
    ts = 1.0 / fs
    N = len(dataArr)
    Mmax = 2**np.floor(np.log2(N / 2))
    M = np.logspace(np.log10(1), np.log10(Mmax), num=maxNumM)
    M = np.ceil(M)  # Round up to integer
    M = np.unique(M)  # Remove duplicates
    taus = M * ts  # Compute 'cluster durations' tau

    # Compute Allan variance
    allanVar = np.zeros(len(M))
    for i, mi in enumerate(M):
        twoMi = int(2 * mi)
        mi = int(mi)
        allanVar[i] = np.sum(
            (dataArr[twoMi:N] - (2.0 * dataArr[mi:N-mi]) + dataArr[0:N-twoMi])**2
        )
    
    allanVar /= (2.0 * taus**2) * (N - (2.0 * M))
    return (taus, np.sqrt(allanVar))  # Return deviation (dev = sqrt(var))

file_path = os.path.join(folder_path, file_name)
# Lee el archivo CSV
# Lee el archivo CSV con configuración para coma como separador decimal
df = pd.read_csv(file_path, delimiter= ";", decimal=',')

# Convertir las columnas de giroscopio a numéricas, reemplazar valores no numéricos con NaN
df['Gyr_X'] = pd.to_numeric(df['Gyr_X'], errors='coerce')
df['Gyr_Y'] = pd.to_numeric(df['Gyr_Y'], errors='coerce')
df['Gyr_Z'] = pd.to_numeric(df['Gyr_Z'], errors='coerce')

# Eliminar la columna 'Unnamed: 23' si es irrelevante
if 'Unnamed: 23' in df.columns:
    df.drop(columns=['Unnamed: 23'], inplace=True)

# Reemplazar NaN con ceros o con la estrategia que prefieras
df.fillna(0, inplace=True)

# Obtiene los datos de giroscopio
gyro_x = df['Gyr_X'].values
gyro_y = df['Gyr_Y'].values
gyro_z = df['Gyr_Z'].values

ts = 1.0 / fs


# Cálculo de ángulos
thetax = np.cumsum(gyro_x) * ts
thetay = np.cumsum(gyro_y) * ts
thetaz = np.cumsum(gyro_z) * ts

# Verifica los primeros valores de las variables de ángulo integradas
print("thetax:", thetax[:5])
print("thetay:", thetay[:5])
print("thetaz:", thetaz[:5])

# Compute Allan deviations
(taux, adx) = AllanDeviation(thetax, fs, maxNumM=200)
(tauy, ady) = AllanDeviation(thetay, fs, maxNumM=200)
(tauz, adz) = AllanDeviation(thetaz, fs, maxNumM=200)

# Plot data on log-scale
plt.figure()
plt.title('Gyro Allan Deviations')
plt.plot(taux, adx, label='gx')
plt.plot(tauy, ady, label='gy')
plt.plot(tauz, adz, label='gz')
plt.xlabel(r'$\tau$ [sec]')
plt.ylabel('Deviation [deg/sec]')
plt.grid(True, which="both", ls="-", color='0.65')
plt.legend()
plt.xscale('log')
plt.yscale('log')
plt.show()
