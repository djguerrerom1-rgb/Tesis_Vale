import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.fft import fft, fftfreq
from scipy.stats import shapiro

# Ruta a la carpeta que contiene los archivos CSV
folder_path = r"C:\Users\Valentina\Documents\TESIS 1\gyro allan"

# Config. params
file_name = 'gyro_allan_tibia.csv'# CSV data file "gx,gy,gz"
fs = 60  # Sample rate [Hz]

def AllanDeviation(dataArr: np.ndarray, fs: float, maxNumM: int=100):
    """Compute the Allan deviation (sigma) of time-series data.

    Algorithm obtained from Mathworks:
    https://www.mathworks.com/help/fusion/ug/inertial-sensor-noise-analysis-using-allan-variance.html

    Args
    ----
        dataArr: 1D data array
        fs: Data sample frequency in Hz
        maxNumM: Number of output points
    
    Returns
    -------
        (taus, allanDev): Tuple of results
        taus (numpy.ndarray): Array of tau values
        allanDev (numpy.ndarray): Array of computed Allan deviations
    """
    ts = 1.0 / fs
    N = len(dataArr)
    Mmax = 2**np.floor(np.log2(N / 2))
    M = np.logspace(np.log10(1), np.log10(Mmax), num=maxNumM)
    M = np.ceil(M)  # Round up to integer
    M = np.unique(M)  # Remove duplicates
    taus = M * ts  # Compute 'cluster durations' tau

    # Compute Allan variance
    allanVar = np.zeros(len(M))
    for i, mi in enumerate(M):
        twoMi = int(2 * mi)
        mi = int(mi)
        allanVar[i] = np.sum(
            (dataArr[twoMi:N] - (2.0 * dataArr[mi:N-mi]) + dataArr[0:N-twoMi])**2
        )
    
    allanVar /= (2.0 * taus**2) * (N - (2.0 * M))
    return (taus, np.sqrt(allanVar))  # Return deviation (dev = sqrt(var))



# Cargar archivo CSV
file_path = os.path.join(folder_path, file_name)
df = pd.read_csv(file_path, delimiter=",", decimal='.')

# Convertir las columnas de giroscopio a numéricas y manejar errores
df['Gyr_X'] = pd.to_numeric(df['Gyr_X'], errors='coerce')
df['Gyr_Y'] = pd.to_numeric(df['Gyr_Y'], errors='coerce')
df['Gyr_Z'] = pd.to_numeric(df['Gyr_Z'], errors='coerce')

# Definir umbral para exclusión de valores anómalos
threshold = 1  # Ajusta este valor según sea necesario

# Reemplazar valores anómalos con NaN
df['Gyr_X'] = df['Gyr_X'].apply(lambda x: np.nan if abs(x) > threshold else x)
df['Gyr_Y'] = df['Gyr_Y'].apply(lambda x: np.nan if abs(x) > threshold else x)
df['Gyr_Z'] = df['Gyr_Z'].apply(lambda x: np.nan if abs(x) > threshold else x)

# Eliminar filas con NaN para evitar errores en futuros cálculos
df.dropna(subset=['Gyr_X', 'Gyr_Y', 'Gyr_Z'], inplace=True)

# Guardar los datos filtrados para futuras operaciones
gyro_x_filtered = df['Gyr_X'].values
gyro_y_filtered = df['Gyr_Y'].values
gyro_z_filtered = df['Gyr_Z'].values

# Calcular sesgo (bias) de los datos filtrados
gyro_x_bias = np.mean(gyro_x_filtered)
gyro_y_bias = np.mean(gyro_y_filtered)
gyro_z_bias = np.mean(gyro_z_filtered)

# Mostrar los sesgos calculados
print(f"Sesgo Gyr_X: {gyro_x_bias}")
print(f"Sesgo Gyr_Y: {gyro_y_bias}")
print(f"Sesgo Gyr_Z: {gyro_z_bias}")

# Corregir lecturas
gyro_x = gyro_x_filtered - gyro_x_bias
gyro_y = gyro_y_filtered - gyro_y_bias
gyro_z = gyro_z_filtered - gyro_z_bias

# Imprimir algunos valores para verificar
print("Gyr_X:", gyro_x[:5])
print("Gyr_Y:", gyro_y[:5])
print("Gyr_Z:", gyro_z[:5])

ts = 1.0 / fs

# Calculate gyro angles
thetax = np.cumsum(gyro_x) * ts  # [deg]
thetay = np.cumsum(gyro_y) * ts
thetaz = np.cumsum(gyro_z) * ts

# Verifica los primeros valores de las variables de ángulo integradas
print("thetax:", thetax[:5])
print("thetay:", thetay[:5])
print("thetaz:", thetaz[:5])

# Compute Allan deviations
(taux, adx) = AllanDeviation(thetax, fs, maxNumM=200)
(tauy, ady) = AllanDeviation(thetay, fs, maxNumM=200)
(tauz, adz) = AllanDeviation(thetaz, fs, maxNumM=200)

# Plot data on log-scale
plt.figure()
plt.title('Gyro Allan Deviations')
plt.plot(taux, adx, label='gx')
plt.plot(tauy, ady, label='gy')
plt.plot(tauz, adz, label='gz')
plt.xlabel(r'$\tau$ [sec]')
plt.ylabel('Deviation [deg/sec]')
plt.grid(True, which="both", ls="-", color='0.65')
plt.legend()
plt.xscale('log')
plt.yscale('log')
plt.show()


# Recorre todos los archivos en la carpeta
for file_name in os.listdir(folder_path):
    if file_name.endswith(".csv"):
        file_path = os.path.join(folder_path, file_name)
        
        # Lee el archivo CSV
        df = pd.read_csv(file_path)
        
        # Lista de señales ya filtradas y corregidas de sesgo
        gyro_columns = [('Gyr_X', gyro_x), ('Gyr_Y', gyro_y), ('Gyr_Z', gyro_z)]
        
         # Función para calcular autocorrelación
def autocorrelation(signal):
    result = np.correlate(signal, signal, mode='full')
    return result[result.size // 2:]

# Lista de señales ya filtradas y corregidas de sesgo
gyro_columns = [('Gyr_X', gyro_x), ('Gyr_Y', gyro_y), ('Gyr_Z', gyro_z)]

# Análisis para cada eje (X, Y, Z) del giroscopio
for axis_name, axis_data in gyro_columns:
    print(f"\n--- Análisis del Giroscopio en el eje {axis_name} ---")
    
    # Usar los datos ya filtrados y corregidos de sesgo (gyro_x, gyro_y, gyro_z)
    data = axis_data
    
    # --- Autocorrelación ---
    autocorr = autocorrelation(data)
    plt.plot(autocorr)
    plt.title(f"Autocorrelación de la señal ({axis_name})")
    plt.xlabel("Retardo")
    plt.ylabel("Autocorrelación")
    plt.grid(True)
    plt.show()

    # --- Distribución de los datos ---
    sns.histplot(data, kde=True)
    plt.title(f"Distribución de la señal ({axis_name})")
    plt.grid(True)
    plt.show()

    # Prueba de normalidad Shapiro-Wilk
    stat, p_value = shapiro(data)
    print(f'Prueba de normalidad Shapiro-Wilk para {axis_name}: p-value = {p_value}')
    if p_value > 0.05:
        print(f"La señal en {axis_name} tiene una distribución normal (ruido gaussiano blanco).")
    else:
        print(f"La señal en {axis_name} no tiene una distribución normal.")

    # --- Transformada de Fourier (Espectro de Potencia) ---
    N = len(data)
    T = 1.0 / fs  # Frecuencia de muestreo, ajustada según la variable 'fs'

    yf = fft(data)
    xf = fftfreq(N, T)[:N//2]

    # Gráfica del espectro de potencia
    plt.plot(xf, np.abs(yf[:N//2]))
    plt.title(f"Espectro de potencia ({axis_name})")
    plt.xlabel("Frecuencia (Hz)")
    plt.ylabel("Amplitud")
    plt.grid(True)
    plt.show()
