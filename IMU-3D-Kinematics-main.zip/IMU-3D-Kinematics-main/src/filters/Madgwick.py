import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from ahrs.filters import Madgwick

# Ruta del archivo CSV (ajusta según corresponda)
file_path = r"C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\24.02.2025\XSENS\XSENS CUATERNIONES\133310\muslo_der_val_D422CD002A96_20250224_133310.csv"

# Cargar datos del CSV y tomar solo los primeros 600 datos
df = pd.read_csv(file_path).iloc[1000:3000]

# Extraer cuaterniones originales
quaternions = np.column_stack((df["Quat_W"], df["Quat_X"], df["Quat_Y"], df["Quat_Z"]))

# Extraer datos de acelerómetro y giroscopio
acc = np.column_stack((df["Acc_X"], df["Acc_Y"], df["Acc_Z"]))
gyr = np.column_stack((df["Gyr_X"], df["Gyr_Y"], df["Gyr_Z"]))
gyr = np.radians(gyr)
#gyr -= np.mean(gyr[0:600], axis=0) 
# Parámetros del filtro Madgwick
madgwick = Madgwick(gain=0.005, frequency=60)

# Inicializar lista para los cuaterniones filtrados
filtered_quaternions = np.zeros((2000, 4))
filtered_quaternions[0] = quaternions[0]  # Empezamos con el primer cuaternión

# Aplicar el filtro Madgwick
for i in range(1, 2000):
    filtered_quaternions[i] = madgwick.updateIMU(filtered_quaternions[i-1], gyr[i], acc[i])

# Graficar los cuaterniones originales y filtrados
plt.figure(figsize=(12, 6))

# Cuaterniones originales
plt.subplot(2, 1, 1)
#plt.plot(df.index, quaternions[:, 0], label='Quat_W', alpha=0.8)
#plt.plot(df.index, quaternions[:, 1], label='Quat_X', alpha=0.8)
plt.plot(df.index, quaternions[:, 2], label='Quat_Y', alpha=0.8, color="#d03c34")
#plt.plot(df.index, quaternions[:, 3], label='Quat_Z', alpha=0.8)
plt.title("Cuaterniones Originales del Sensor")
plt.xlabel("Muestras")
plt.ylabel("Valor")
plt.legend()
plt.grid()

# Cuaterniones filtrados
plt.subplot(2, 1, 2)
#plt.plot(df.index, filtered_quaternions[:, 0], label='Quat_W', alpha=0.8)
#plt.plot(df.index, filtered_quaternions[:, 1], label='Quat_X', alpha=0.8)
plt.plot(df.index, filtered_quaternions[:, 2], label='Quat_Y', alpha=0.8, color="#d03c34")
#plt.plot(df.index, filtered_quaternions[:, 3], label='Quat_Z', alpha=0.8)
plt.title("Cuaterniones Normalizados con Filtro Madgwick")
plt.xlabel("Muestras")
plt.ylabel("Valor")
plt.legend()
plt.grid()

plt.tight_layout()
plt.show()


# # Giroscopio en XYZ
# plt.figure()
# plt.plot(df.index, gyr[:, 0], label='Gyr_X', alpha=0.8)
# plt.plot(df.index, gyr[:, 1], label='Gyr_Y', alpha=0.8)
# plt.plot(df.index, gyr[:, 2], label='Gyr_Z', alpha=0.8)
# plt.title("Señal del Giroscopio")
# plt.xlabel("Muestras")
# plt.ylabel("Velocidad Angular (rad/s)")
# plt.legend()
# plt.grid()
# plt.tight_layout()
# plt.show()