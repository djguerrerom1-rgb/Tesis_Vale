import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from scipy.spatial.transform import Rotation as R
from scipy.signal import find_peaks, correlate
from scipy.signal import windows, fftconvolve

from scipy.fftpack import fft, fftfreq
from scipy.signal import butter, filtfilt
from sklearn.metrics import mean_squared_error

"""  Este código estaba probando cómo limpiar y aislar la frecuencia principal
de la marcha en una señal ruidosa usando análisis en frecuencia y filtrado."""


# Sampling parameters
fs = 100  # Hz
t = np.linspace(0, 10, 10 * fs)

# Simulate a noisy gait signal
np.random.seed(42)
signal_original = (
    1.0 * np.sin(2 * np.pi * 1.2 * t) +   # Primary gait frequency (~1.2 Hz)
    0.5 * np.sin(2 * np.pi * 2.5 * t) +   # Secondary gait harmonic
    0.2 * np.random.randn(len(t))        # Noise
)

# Apply Hanning window
window = windows.hann(len(signal_original))
signal_windowed = signal_original * window

# Compute FFT
fft_values = fft(signal_windowed)
fft_magnitude = np.abs(fft_values) / len(signal_windowed)
frequencies = fftfreq(len(signal_windowed), d=1/fs)

# Keep positive frequencies only
positive_freqs = frequencies[:len(frequencies)//2]
positive_fft_magnitude = fft_magnitude[:len(frequencies)//2]

# Bandpass filter based on FFT profile
def bandpass_filter(data, lowcut, highcut, fs, order=4):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return filtfilt(b, a, data)

# Filter signal: pass only typical gait range (~0.5–4 Hz)
filtered_signal = bandpass_filter(signal_original, 0.5, 4.0, fs)

# Reference clean gait signal for comparison
signal_reference = 1.0 * np.sin(2 * np.pi * 1.2 * t)

# Compute MSE before and after filtering
mse_before = mean_squared_error(signal_reference, signal_original)
mse_after = mean_squared_error(signal_reference, filtered_signal)

# Plot results
fig, axs = plt.subplots(5, 1, figsize=(12, 18))

axs[0].plot(t, signal_original)
axs[0].set_title("Original Gait Signal (Noisy)")
axs[0].set_xlabel("Time [s]")

axs[1].plot(t, signal_windowed)
axs[1].set_title("Windowed Signal (Hanning)")
axs[1].set_xlabel("Time [s]")

axs[2].plot(positive_freqs, positive_fft_magnitude)
axs[2].set_title("FFT Magnitude Spectrum (Windowed)")
axs[2].set_xlim(0, 10)
axs[2].set_xlabel("Frequency [Hz]")

axs[3].plot(t, filtered_signal)
axs[3].set_title("Bandpass Filtered Signal (0.5–4 Hz)")
axs[3].set_xlabel("Time [s]")

axs[4].plot(t, signal_reference, label="Reference")
axs[4].plot(t, signal_original, label=f"Original (MSE: {mse_before:.4f})", alpha=0.6)
axs[4].plot(t, filtered_signal, label=f"Filtered (MSE: {mse_after:.4f})", alpha=0.8)
axs[4].set_title("Comparison with Reference")
axs[4].legend()
axs[4].set_xlabel("Time [s]")

plt.tight_layout()
plt.show()
