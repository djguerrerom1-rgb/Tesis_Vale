import pandas as pd
import numpy as np
import os
import re
from scipy.stats import ttest_rel

# Rutas
base_path = r'C:\Users\Valentina\OneDrive - Universidad de los andes\Documentos\GitHub\IMU-3D-Kinematics\data\SUJETOS\RESULTADOS'
file_xsens = os.path.join(base_path, 'CICLOS_XSENS_COPIA.xlsx')
file_3dma  = os.path.join(base_path, 'CICLOS_3DMA_COPIA.xlsx')

ANGULOS = [
    'cadera_der_f_e', 'cadera_der_abd_add',
    'cadera_izq_f_e', 'cadera_izq_abd_add',
    'rodilla_der_f_e', 'rodilla_der_abd_add',
    'rodilla_izq_f_e', 'rodilla_izq_abd_add',
    'tobillo_der_f_e', 'tobillo_izq_f_e'
]

def parse_col(col):
    # Para ambos métodos: Amid_Delgado_3_DERECHO_2 ó Amid_Delgado_3_ #14
    m = re.match(r"(.+?)_(\d+)_", col)
    if m:
        return (m.group(1), m.group(2))  # (sujeto, captura)
    return None

resultados_t = []
detalles = []

for angulo in ANGULOS:
    df_xsens = pd.read_excel(file_xsens, sheet_name=angulo)
    df_3dma  = pd.read_excel(file_3dma, sheet_name=angulo)
    
    cols_xsens = [c for c in df_xsens.columns if c != 'Ciclo de marcha (%)']
    cols_3dma  = [c for c in df_3dma.columns if c != 'Ciclo de marcha (%)']
    
    # Agrupar columnas por (sujeto, captura)
    xsens_proms = {}
    for col in cols_xsens:
        key = parse_col(col)
        if key:
            xsens_proms.setdefault(key, []).append(col)
    
    threedma_proms = {}
    for col in cols_3dma:
        key = parse_col(col)
        if key:
            threedma_proms.setdefault(key, []).append(col)
    
    # Solo los pares comunes (por captura)
    comunes = sorted(set(xsens_proms.keys()) & set(threedma_proms.keys()))
    xsens_vals, threedma_vals, etiquetas = [], [], []
    for key in comunes:
        mean_xsens = df_xsens[xsens_proms[key]].values.mean()
        mean_3dma  = df_3dma[threedma_proms[key]].values.mean()
        xsens_vals.append(mean_xsens)
        threedma_vals.append(mean_3dma)
        etiquetas.append('_'.join(key))
        detalles.append({
            "angulo": angulo,
            "captura": '_'.join(key),
            "xsens": mean_xsens,
            "3dma": mean_3dma,
            "diff": mean_xsens - mean_3dma
        })
    
    if len(xsens_vals) < 2:
        print(f"⚠️ Muy pocos pares para t-test en {angulo}: {len(xsens_vals)}")
        continue

    x = np.array(xsens_vals)
    y = np.array(threedma_vals)
    t_stat, p_val = ttest_rel(x, y)
    diff_mean = np.mean(x - y)
    
    resultados_t.append({
        "angulo": angulo,
        "n": len(x),
        "xsens_mean": np.mean(x),
        "3dma_mean": np.mean(y),
        "diff_mean": diff_mean,
        "t_stat": t_stat,
        "p_val": p_val
    })

# Guardar resumen de la t pareada por ángulo
df_t = pd.DataFrame(resultados_t)
t_path = os.path.join(base_path, "T_PAREADA_XSENS_vs_3DMA.xlsx")
df_t.to_excel(t_path, index=False)
print("✅ Resultados de la t pareada guardados en:", t_path)

# Guardar tabla detalle de todos los pares
df_detalle = pd.DataFrame(detalles)
detalle_path = os.path.join(base_path, "PAREJAS_CAPTURA_XSENS_3DMA.xlsx")
df_detalle.to_excel(detalle_path, index=False)
print("✅ Tabla de promedios individuales guardada en:", detalle_path)
