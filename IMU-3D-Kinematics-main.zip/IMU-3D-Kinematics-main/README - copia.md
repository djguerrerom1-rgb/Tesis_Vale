# IMU-3D-Kinematics
Tesis de IBIO

## LINKS Importantes

https://stackoverflow.com/questions/2812520/dealing-with-multiple-python-versions-and-pip

EDITAMOS DESDE WEB
