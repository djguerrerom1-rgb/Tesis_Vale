import numpy as np

""" 
Este código permite almacenar en dos diccionarios acc y mag calibrados con MAGNETO,
luego los convierte a un archivo .txt 

NOTA: correr la línea de transformación a archivo .txt una vez estén almacenados todos los sensores 
con static calibration
*Correr primero calibration_xsens para obtener los archivos de calibración que van a magneto
"""
# Inicializar un diccionario para almacenar los datos del acelerómetro
accelerometer_data = {}

# Inicializar un diccionario para almacenar los datos del magnetómetro
magnetometer_data = {}

def input_accelerometer_data():
    """
    Solicita al usuario que ingrese una matriz 3x3 y un vector b para un sensor de acelerómetro.
    
    Retorna:
    - dict: Un diccionario con la matriz A y el vector b del acelerómetro.
    """

    # Ingresar el nombre del acelerómetro
    sensor_name_acc = input("Ingresa el nombre del acelerómetro: ")

    # Ingresar la matriz 3x3 del acelerómetro
    A_acc = []
    print(f"Ingresando datos para el acelerómetro: {sensor_name_acc}")
    print("Ingresa los elementos de la matriz 3x3:")
    for i in range(3):
        row = input(f"Fila {i + 1} (separar elementos por espacio): ")
        A_acc.append(list(map(float, row.split())))

    A_acc = np.array(A_acc)

    # Ingresar el vector b del acelerómetro
    b_acc = []
    print("Ingresa los elementos del vector b (debe tener 3 elementos):")
    for i in range(3):
        b_element = float(input(f"Elemento {i + 1}: "))
        b_acc.append(b_element)

    b_acc = np.array(b_acc)

    # Almacenar en el diccionario del acelerómetro
    accelerometer_data[sensor_name_acc] = {'A': A_acc.tolist(), 'b': b_acc.tolist()}

    return accelerometer_data


def input_magnetometer_data():
    """
    Solicita al usuario que ingrese una matriz 3x3 y un vector b para un sensor de magnetómetro.
    
    Retorna:
    - dict: Un diccionario con la matriz A y el vector b del magnetómetro.
    """

    # Ingresar el nombre del magnetómetro
    sensor_name_mag = input("Ingresa el nombre del magnetómetro: ")

    # Ingresar la matriz 3x3 del magnetómetro
    A_mag = []
    print(f"Ingresando datos para el magnetómetro: {sensor_name_mag}")
    print("Ingresa los elementos de la matriz 3x3:")
    for i in range(3):
        row = input(f"Fila {i + 1} (separar elementos por espacio): ")
        A_mag.append(list(map(float, row.split())))

    A_mag = np.array(A_mag)

    # Ingresar el vector b del magnetómetro
    b_mag = []
    print("Ingresa los elementos del vector b (debe tener 3 elementos):")
    for i in range(3):
        b_element = float(input(f"Elemento {i + 1}: "))
        b_mag.append(b_element)

    b_mag = np.array(b_mag)

    # Almacenar en el diccionario del magnetómetro
    magnetometer_data[sensor_name_mag] = {'A': A_mag.tolist(), 'b': b_mag.tolist()}

    return magnetometer_data


def save_data_to_file(accelerometer_data, magnetometer_data, filename):
    """
    Guarda los datos de los sensores de acelerómetro y magnetómetro en un archivo.
    
    Parámetros:
    - accelerometer_data: Diccionario con los datos del acelerómetro.
    - magnetometer_data: Diccionario con los datos del magnetómetro.
    - filename: Nombre del archivo donde se guardarán los datos.
    """
    with open(filename, 'w') as f:
        # Datos del acelerómetro
        for sensor, values in accelerometer_data.items():
            f.write(f"Sensor Acelerómetro: {sensor}\n")
            f.write("Matriz A:\n")
            for row in values['A']:
                f.write("\t".join(map(str, row)) + "\n")
            f.write("Vector b:\n")
            f.write("\t".join(map(str, values['b'])) + "\n\n")

        # Datos del magnetómetro
        for sensor, values in magnetometer_data.items():
            f.write(f"Sensor Magnetómetro: {sensor}\n")
            f.write("Matriz A:\n")
            for row in values['A']:
                f.write("\t".join(map(str, row)) + "\n")
            f.write("Vector b:\n")
            f.write("\t".join(map(str, values['b'])) + "\n\n")

    print(f"Datos guardados en: {filename}")

#input_accelerometer_data()
#input_magnetometer_data()
    
# Solicitar nombre del archivo para guardar
filename = "magneto_file_acc_mag_static.txt"

# Guardar ambos diccionarios en el archivo - solo correr esta línea una vez 
save_data_to_file(accelerometer_data, magnetometer_data, filename)
